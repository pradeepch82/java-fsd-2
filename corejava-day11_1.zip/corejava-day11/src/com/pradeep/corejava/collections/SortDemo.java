package com.pradeep.corejava.collections;

public class SortDemo {
public static void main(String[] args) {
	
}
}
