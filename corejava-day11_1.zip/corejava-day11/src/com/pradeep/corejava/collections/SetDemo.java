package com.pradeep.corejava.collections;

public class SetDemo {
public static void main(String[] args) {
	
}
}
