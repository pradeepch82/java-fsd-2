package com.pradeep.corejava.collections;

public class ListDemo {
public static void main(String[] args) {
	
}
}
