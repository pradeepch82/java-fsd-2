package com.pradeep.corejava.collections;

public class MapDemo {
public static void main(String[] args) {
	
}
}
