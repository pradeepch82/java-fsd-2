package com.pradeep.corejava.collections;

public class NonGeneric {

private Object ref;

public NonGeneric() {
}

public NonGeneric(Object ref) {
	this.ref = ref;
}

public Object getRef() {
	return ref;
}

public void setRef(Object ref) {
	this.ref = ref;
}


void showDetails() {
	
	System.out.println("Current Class :"+this.getClass().getName());
	System.out.println("Ref     Class :"+ref.getClass().getName());
	
	
}


public static void main(String[] args) {
	
	NonGeneric n1=new NonGeneric(11); //int =>Integer=>Object
	
	NonGeneric n2=new NonGeneric("Pradeep");//String =>Object

	NonGeneric n3=new NonGeneric(667.788f);//float=>Float =>Object

	n1.showDetails();
	n2.showDetails();
	n3.showDetails();
	
	
	
	
	Integer a=(Integer)n2.getRef();
	
	String b=(String)n1.getRef();
	
	
	System.out.println(" a: "+a);
	System.out.println(" b: "+b);
	System.out.println(" c: "+n3.getRef());
	
	
	n1=n2;
	
	
}
	
	
	
	
	
	
}
