package com.pradeep.corejava.exceptions;

public class Ex5 {
public static void main(String[] args) {
	
	
	try {
		
		Class c=Class.forName("com.pradeep.corejava.exceptions.Ex");
		
		System.out.println(c.getName()+"  is loaded...  ");
		
		Object o=c.newInstance();
		
		
		
		
	} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
}
}
