package com.pradeep.corejava.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Stack;
import java.util.Vector;

public class ListDemo {
	

 List<String> frutis;
 
 public ListDemo() {
  	// frutis=new ArrayList<>();//java 7 feature
	// frutis=new LinkedList<>();//java 7 feature
	// frutis=new Vector<>();//java 7 feature
	 frutis=new Stack<>();//java 7 feature
 
  	 System.out.println("Initial Size :"+frutis.size());
  	 System.out.println("Contents :"+frutis);
  	 
  	 
 }
 
 
 //add the elements
 void add() {
	 
	 frutis.add("APPLE"); //0
	 frutis.add("GRAPES");//1
	 frutis.add("BANANA");//2
	 frutis.add("SAPOTA");//3
	 frutis.add(0,"PINEAPLE");
	
	 System.out.println("After adding fruits");
	 System.out.println("Initial Size :"+frutis.size());
  	 System.out.println("Contents :"+frutis);
  	 
	
 }
 
 
 void update() {
	 
	 frutis.set(0, "Orange");
	 frutis.remove("BANANA");
	 frutis.remove(2);
	 frutis.add("APPLE");
	 
	 

	 System.out.println("After modifying  fruits");
	 System.out.println("Initial Size :"+frutis.size());
  	 System.out.println("Contents :"+frutis);
  	 
	
  	 
  	System.out.println("Is Apple Present :"+frutis.contains("APPLE"));
  	System.out.println("Is apple Present :"+frutis.contains("apple"));
 	 
  	System.out.println("Index Of Apple :"+frutis.indexOf("APPLE"));
  	System.out.println("Last Index Of Apple :"+frutis.lastIndexOf("APPLE"));
  	
  	List <String> list=Arrays.asList("APPLE","GRAPES");
  	
  	System.out.println("List :"+list);
  	
  //	frutis.addAll(list); 
  	// frutis.removeAll(list); 
  	   frutis.retainAll(list);
  	
	System.out.println("List :"+frutis);
  		
  	
	 
 }
 
 
 
 
 
 
 
 void show() {
	 //toString
	 System.out.println("USing To String");
	 System.out.println("===========================");
	 System.out.println(frutis);
	 
	 System.out.println("Using For loop");
	 System.out.println("===========================");
	 for(int i=0;i<frutis.size();i++)
		 System.out.println(frutis.get(i));
	 
	
	 System.out.println("ForEach Loop");
	 System.out.println("===========================");
	 for(String s:frutis)
		 System.out.println(s);
	 
	 
	 Iterator<String> it=frutis.iterator();
	 
	 System.out.println("Using iterator");
	 System.out.println("============================");
	 
	 while(it.hasNext())
		 System.out.println(it.next());
		 
	
 ListIterator<String> lit=frutis.listIterator();
	 
	 System.out.println("Using iterator");
	 System.out.println("============================");
	 
	 System.out.println("In forward direction");
	 System.out.println("================================");
	 while(lit.hasNext())
		 System.out.println(lit.next());
	 
	 System.out.println("In backward direction");
	 System.out.println("================================");
	 while(lit.hasPrevious())
		 System.out.println(lit.previous());
	 
	 
	 
 }
 	
	
	
	
	
	
	
public static void main(String[] args) {

	ListDemo ld=new ListDemo();
	ld.add();
	ld.update();
	//ld.show();
	
}
}
