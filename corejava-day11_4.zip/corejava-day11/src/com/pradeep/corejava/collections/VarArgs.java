package com.pradeep.corejava.collections;


public class VarArgs {
	
	static void sum(int a,int b) {
		System.out.println("a+b  :"+(a+b));
	}

	static void sum(int a,int b,int c) {
		System.out.println("a+b+c  :"+(a+b+c));
	}
	
	
       //var args
	static void sum(int ...arr) {
	
		int sum=0;
		int n=arr.length;
		for(int s:arr)
		sum=sum+s;
		
		System.out.println("sum of  "+n+"  numbers : "+sum);
		
	}
	
	
public static void main(String[] args) {
	
	sum(10,20);
	sum(10,20,30);
	sum(10,20,30,40);
	sum(10,20,30,40,50);
	sum(10,20,30,40,50,60,70);
	   	
}
}
