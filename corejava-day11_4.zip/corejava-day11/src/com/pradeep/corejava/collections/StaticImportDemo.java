package com.pradeep.corejava.collections;

import static java.lang.Math.*;

public class StaticImportDemo {
public static void main(String[] args) {
	
	System.out.println("PI            :"+PI);
	System.out.println("POW(10,2)     :"+pow(10, 2));
	System.out.println("max(10,2)     :"+max(10, 2));
	System.out.println("min(10,2)     :"+min(10, 2));
    	
}
}
