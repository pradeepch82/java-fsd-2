package com.pradeep.corejava.exceptions;

public class Ex3 {
public static void main(String[] args) {
	
	
	try {
	int n=args.length;
	System.out.println("Number of Argument "+n);
	System.out.println("Open files....");
	int a=100/n;
	System.out.println("a ="+a);
		
	int arr[]= {10,20,30};
	
	arr[1]=67;
	
	String s=null;
	
	s.toLowerCase();
		
	}
	

	catch(ArithmeticException|ArrayIndexOutOfBoundsException|NullPointerException e) {
	e.printStackTrace();
	}
	
		
	finally{
		System.out.println("Close the files...");
	}	
	
}
}
