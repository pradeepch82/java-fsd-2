package com.pradeep.corejava.exceptions;

public class Ex6 {
public static void main(String[] args) throws Exception {
	
		
		Class c=Class.forName("com.pradeep.corejava.exceptions.Ex");
		
		System.out.println(c.getName()+"  is loaded...  ");
		
		Object o=c.newInstance();
	
	
	
	
}
}
