import { Component, OnInit } from '@angular/core';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
  providers:[UsersService]
  
})
export class UserListComponent implements OnInit {

  title='All Users';

  users:any;

  message='';


  constructor(private us:UsersService) {
    console.log("============UsersListComponent created======")
   }

  ngOnInit(): void {
    console.log("============UsersListComponent initialized======")
    this.getAllUsers();
  }

  ngOnDestroy(): void {
    console.log("============UsersListComponent destroyed======")
    
  }


  getAllUsers(){
     this.us.getAllUsers().subscribe(response=>this.users=response,error=>this.message=error);
  }

}
