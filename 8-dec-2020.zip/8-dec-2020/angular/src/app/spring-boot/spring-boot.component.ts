import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-spring-boot',
  templateUrl: './spring-boot.component.html',
  styleUrls: ['./spring-boot.component.css']
})
export class SpringBootComponent implements OnInit {

  

  title="Spring Boot Customer API";

  customers:any;

  message="";


  customer:any;


  add=false;
  update=false;



  constructor(private cs:CustomerService) {

     console.log("============SpringBootComponent component created===============");
  }

  ngOnInit(): void {

    
    console.log("============SpringBootComponent component initialized===============");
    this.getAllCustomers();

  }

  ngOnDestroy(): void {
    console.log("============SpringBootComponent component destroyed===============");
  }


  getAllCustomers(){
    this.cs.getAllCustomers().subscribe(response=>this.customers=response,error=>this.message=error);
  }

  newCustomer(){
    this.customer={"customerId":0,"firstName":"","lastName":"","gender":"","email":"","address":"","city":"","state":"","registrationDate":new Date()};

    this.update=true;
    this.add=false;


  }

  getCustomerById(customerId:number){

    this.update=false;
    this.add=true;

    this.cs.getCustomerById(customerId).subscribe(response=>this.customer=response,error=>this.message=error);
  }
  
  deleteCustomerById(customerId:number){
    this.cs.deleteCustomerById(customerId).subscribe(response=>this.customers=response,error=>this.message=error);
  }

  updateCustomerById(customerId:number){
    this.cs.updateCustomerById(customerId,this.customer).subscribe(response=>this.customers=response,error=>this.message=error);
    this.customer=null;
   
  }

  
  addCustomer(){
    this.cs.addCustomer(this.customer).subscribe(response=>this.customers=response,error=>this.message=error);
   this.customer=null;

  }



}
