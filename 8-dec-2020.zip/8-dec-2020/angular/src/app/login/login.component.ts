import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  title="Login Form";

  loginForm:FormGroup;


  model: any = {};

  constructor(private fb:FormBuilder,private router:Router) {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent created   $$$$$$$$$$")
  }

  ngOnInit() {

    this.loginForm=this.fb.group({
      //email:["ram@gmail.com",Validators.required],
      email:["ram@gmail.com",Validators.compose([Validators.required,Validators.email])],
      password:["ram@1234",Validators.compose([Validators.required,Validators.minLength(8),Validators.maxLength(10)])]
       });
       console.log("$$$$$$$$$$$$$$$$$$ LoginComponent initialized   $$$$$$$$$$")
  
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterViewInit  $$$$$$$$$$")
  }

  ngDoCheck() {
    console.log("############ LoginComponent  ngDoCheck #############");
  }



  get lf(){
    return this.loginForm;
  }


  
  submitForm(lf:any){


    sessionStorage.setItem("email",lf.email);
    alert("Login successfull.");
    this.router.navigate(['/home']);
    }


}
