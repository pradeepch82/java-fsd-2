import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit,OnDestroy{


  title="Top 5 Technologies";  //string


  technologies=[
    {id:1,name:'Angular',likes:0,dislikes:0},
    {id:2,name:'AWS',likes:0,dislikes:0},
    {id:3,name:'PCF',likes:0,dislikes:0},
    {id:4,name:'Sales Force',likes:0,dislikes:0},
    {id:5,name:'Kubernetes',likes:0,dislikes:0},
  ]; //array






  incrementLikes(t){
    t.likes++;
  }

incrementDislikes(t){
    t.dislikes++;
  }
  




  constructor() { 
    console.log("============TechnologiesComponent component created===============");
  }

  ngOnInit(): void {
    console.log("============TechnologiesComponent component initialized===============");
    
  }

  ngOnDestroy(): void {
    console.log("============TechnologiesComponent component destroyed===============");
  }

}
