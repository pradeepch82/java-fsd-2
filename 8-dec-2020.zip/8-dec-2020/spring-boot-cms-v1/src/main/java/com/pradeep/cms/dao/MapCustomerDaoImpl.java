package com.pradeep.cms.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pradeep.cms.data.CustomerMap;
import com.pradeep.cms.model.Customer;

@Repository("mapCustomerDaoImpl")
//@Component
public class MapCustomerDaoImpl implements CustomerDao {

	
	public MapCustomerDaoImpl() {
	System.out.println("=========MapCustomerDaoImpl default constructor created ==============");
	}
	
	
	@Override
	public boolean saveCustomer(Customer customer) {
		return CustomerMap.INSTANCE.getMap().put(customer.getCustomerId(), customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		if (CustomerMap.INSTANCE.getMap().containsKey(customer.getCustomerId())) {
			CustomerMap.INSTANCE.getMap().put(customer.getCustomerId(), customer);

			return true;
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		if (CustomerMap.INSTANCE.getMap().containsKey(customerId)) {
			CustomerMap.INSTANCE.getMap().remove(customerId);

			return true;
		}

		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return CustomerMap.INSTANCE.getMap().get(customerId);
	}

	@Override
	public List<Customer> findAllCustomers() {

		return new ArrayList<>(CustomerMap.INSTANCE.getMap().values());
	}

}
