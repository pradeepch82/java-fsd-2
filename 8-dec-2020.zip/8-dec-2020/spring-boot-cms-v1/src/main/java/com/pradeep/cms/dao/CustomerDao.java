package com.pradeep.cms.dao;

import java.util.List;

import com.pradeep.cms.model.Customer;

public interface CustomerDao {

	boolean saveCustomer(Customer customer);
	boolean updateCustomer(Customer customer);
	boolean deleteCustomer(int customerId);
	Customer findCustomer(int customerId);
	List<Customer> findAllCustomers();

}
