package com.controllers;

import java.util.Date;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/rest")
public class DemoRestController {

	public DemoRestController() {
	
		System.out.println("DemoRest Controller created.....");
	
	}

	@GetMapping(value="/today")
	public  String todayGet() {
		return "GET :Today is :"+new Date();
	}
	
	@PostMapping(value="/today")
	public   String todayPost() {
		return "POST :Today is :"+new Date();
	}
	
	@PutMapping(value="/today")
	public   String todayPut() {
		return "PUT :Today is :"+new Date();
	}
	
	@DeleteMapping(value="/today")
	public   String todayDelete() {
		return "DELETE :Today is :"+new Date();
	}
	
	@PatchMapping(value="/today")
	public   String todayPatch() {
		return "Patch :Today is :"+new Date();
	}
	
}
