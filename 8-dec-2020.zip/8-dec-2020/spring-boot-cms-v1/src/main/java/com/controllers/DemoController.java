package com.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DemoController {

	
	
	
	public DemoController() {
	
		System.out.println("Demo Controller created.....");
	
	}
	
	@RequestMapping(value="/hello",method = RequestMethod.GET)
	public String hello() {
		return "hello";
	}
	
	@RequestMapping(value="/greet",method = RequestMethod.GET)
	public String greet() {
		return "greet";
	}
	
	@RequestMapping(value="/welcome",method = RequestMethod.GET)
	public String welcome() {
		return "welcome";
	}
	
	@RequestMapping(value="/today")
	public  @ResponseBody String today() {
		return "Today is :"+new Date();
	}
		
}
