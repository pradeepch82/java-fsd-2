package com.pradeep.spring.app1;

public class HelloWorld {

	private String message; //dependency

	public HelloWorld() {
		System.out.println("HelloWorld default constructor executed....");
	}

	
	//constructor injection
	public HelloWorld(String message) {
		this.message = message;
		System.out.println("HelloWorld param constructor executed....");

	}

	public String getMessage() {
		
		System.out.println("Message  :"+message);
		
		return message;
	}

	//setter injection
	public void setMessage(String message) {
		this.message = message;
		System.out.println("HelloWorld setMessage  ...");

	}

}
