package com.pradeep.spring.app1;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class MainApp {
	public static void main(String[] args) {

		// create a spring core container
		XmlBeanFactory f = new XmlBeanFactory(new ClassPathResource("beans.xml"));

	}
}
