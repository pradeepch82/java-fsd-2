import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlbumsComponent } from './albums/albums.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CommentsComponent } from './comments/comments.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NestedComponent } from './nested/nested.component';
import { PhotosComponent } from './photos/photos.component';
import { PostsComponent } from './posts/posts.component';
import { RegisterComponent } from './register/register.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { TodosComponent } from './todos/todos.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserTableComponent } from './user-table/user-table.component';
import { UsersComponent } from './users/users.component';
import { ViewChildComponent } from './view-child/view-child.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'basics',component:AngularBasicsComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'viewchild',component:ViewChildComponent},
  {path:'customdirective',component:CustomDirectivesComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'springboot',component:SpringBootComponent},
  {path:'nested',component:NestedComponent},
  {path:'casestudy',component:CaseStudyComponent,
  children:[
    {path:'users',component:UsersComponent,

    children:[
      {path:'list',component:UserListComponent},
      {path:'table',component:UserTableComponent},
     ]
  
    },
    {path:'posts',component:PostsComponent},
    {path:'comments',component:CommentsComponent},
    {path:'todos',component:TodosComponent},
    {path:'albums',component:AlbumsComponent},
    {path:'photos',component:PhotosComponent},
    

  ]




 },


  
  {path:'**',redirectTo:'home'},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
