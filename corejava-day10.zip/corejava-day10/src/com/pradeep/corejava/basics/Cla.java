package com.pradeep.corejava.basics;

import java.util.Arrays;
/*
 
 
 Command Line Arguments
 ========================
  Parameters passed to main method through command line before running the program is
 called command line arguments.
  
  
 * */
public class Cla {

	public static void main(String[] args) {
		System.out.println(Arrays.toString(args));

		System.out.println("Number of arguments :"+args.length);
		
	  for(int i=0;i<args.length;i++)
		  System.out.println("args["+i+"] = "+args[i]);

	
	}

}
