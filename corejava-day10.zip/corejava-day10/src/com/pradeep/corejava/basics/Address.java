package com.pradeep.corejava.basics;

public class Address {
private int flatNo;
private String buildngName;
private String area;
private String city;

public Address() {
	
	flatNo=3456;
	buildngName="Akruti";
	area="Shivane";
	city="Pune";
}

public Address(int flatNo, String buildngName, String area, String city) {
	this.flatNo = flatNo;
	this.buildngName = buildngName;
	this.area = area;
	this.city = city;
}

public int getFlatNo() {
	return flatNo;
}

public void setFlatNo(int flatNo) {
	this.flatNo = flatNo;
}

public String getBuildngName() {
	return buildngName;
}

public void setBuildngName(String buildngName) {
	this.buildngName = buildngName;
}

public String getArea() {
	return area;
}

public void setArea(String area) {
	this.area = area;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

@Override
public String toString() {
	return "Address [flatNo=" + flatNo + ", buildngName=" + buildngName + ", area=" + area + ", city=" + city + "]";
}

}
