package com.pradeep.corejava.basics;

import java.util.Scanner;

public class AssociationDemo {
public static void main(String[] args) {
	
	Student student=new Student();
	Address address=new Address();
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Student id :");
	student.setId(sc.nextInt());
	System.out.println("Enter Student name:");
	student.setName(sc.next());
	System.out.println("Enter Flat Number :");
	address.setFlatNo(sc.nextInt());
	System.out.println("Enter Building Name :");
	address.setBuildngName(sc.next());
	System.out.println("Enter Area");
	address.setArea(sc.next());
    System.out.println("Enter city :");
    address.setCity(sc.next());
 	
    //student.setAddress(address); aggregation

 	System.out.println("Student Details :");
 	System.out.println("=======================");
 	System.out.println(student);
	
 	student=null;
 	System.out.println("After destroying student");	
 	System.out.println(student);
 	
 	
 	System.out.println("Address :"+address);
 	
	
	
	
	
}
}
