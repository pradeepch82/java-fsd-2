Assignment
============
Circle     : area perimeter  
Rectangle  : area perimeter
Square     : area perimeter
Shape      : area perimeter


Write Java Application to accept necessary input for above 
shapes from user and display area and perimeter of Shape.



31-Aug to 4-Sep
==================
1.Exception Handling
2.Collections  (java.util)
3.Streams      (java.io)


7-Sep to 12-Sep
==================
1.Threading
4.JDBC
5.Java Features (Java5,Java7,Java8)

