package com.pradeep.corejava.exceptions;

public class Ex4 {
public static void main(String[] args) {
	
	
	
	int n=args.length;
	System.out.println("Number of Argument "+n);
	System.out.println("Open files....");
	int a=100/n;
	System.out.println("a ="+a);
		
	int arr[]= {10,20,30};
	
	arr[1]=67;
	
	String s=null;
	
	s.toLowerCase();
	

    System.out.println("Close the files...");
	
}
}
