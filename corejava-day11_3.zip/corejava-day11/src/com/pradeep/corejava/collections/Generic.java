package com.pradeep.corejava.collections;

public class Generic<T> {

private T ref;

public Generic() {
}

public Generic(T ref) {
	this.ref = ref;
}

public T getRef() {
	return ref;
}

public void setRef(T ref) {
	this.ref = ref;
}


void showDetails() {
	
	System.out.println("Current Class :"+this.getClass().getName());
	System.out.println("Ref     Class :"+ref.getClass().getName());
	
	
}


public static void main(String[] args) {
	
	
	Generic<Integer> g1=new Generic<Integer>(67);
	Generic<String> g2=new Generic<>("Pradeep");//Java 7 -Type inference
	Generic<Float> g3=new Generic<>();
	
	
	g3.setRef(4566.77f);
	
	
	
	
	g1.showDetails();
	g2.showDetails();
	g3.showDetails();
	
	
	
	
	Integer a=g1.getRef();
	String b=g2.getRef();
	Float c=g3.getRef();
	
	
	
	System.out.println(" a: "+a);
	System.out.println(" b: "+b);
	System.out.println(" c: "+c);
	
	
	//g1=g2;
	
	
}
	
	
	
	
	
	
}
