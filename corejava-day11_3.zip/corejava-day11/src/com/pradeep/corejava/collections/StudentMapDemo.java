package com.pradeep.corejava.collections;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class StudentMapDemo {

	Map<Integer, Student> map;

	public StudentMapDemo() {
		map = new HashMap<>();
	}

	void addStudent(Student student) {

		map.put(student.getId(), student);
		System.out.println("Student added.....");

	}

	void updateStudent(Student student) {

		if (map.containsKey(student.getId())) {
			map.put(student.getId(), student);
			System.out.println("Student upate.....");
		} else
			System.out.println("Student doesn't exist");

	}

	void deleteStudent(int studentId) {
		if (map.containsKey(studentId)) {
			map.remove(studentId);
			System.out.println("Student removed.....");
		} else
			System.out.println("Student doesn't exist");
	}

	void showStudent(int studentId) {
		if (map.containsKey(studentId)) {
			
			System.out.println("Student Details\n=========..");
			System.out.println(map.get(studentId));
		} else
			System.out.println("Student doesn't exist");

	}

	void showAllStudents() {

		System.out.println("=========================================");
		System.out.println("All Students");
		System.out.println("=========================================");
		for(Student s:map.values())
		System.out.println(s);
			
	}

	void showAllStudentsSortedByStudentId() {

		
		TreeMap<Integer, Student> tm=new TreeMap<>(map);
		
		
		System.out.println("=========================================");
		System.out.println("All Students Sorted by Student Id");
		System.out.println("=========================================");
		for(Student s:tm.values())
			System.out.println(s);
				
				
		
		
	}

	void showAllStudentsSortedByStudentName() {

	}

	void showAllStudentsSortedByStudentMarks() {

	}

	void showAllStudentsSortedByStudentAge() {

	}

	void showAllStudentsSortedByStudentEmail() {

	}

	void showAllStudentsSortedByStudentDob() {

	}

	void showNumberOfStudents() {
    System.out.println("Number of Students :"+map.size());

	}

	public static void main(String[] args) throws ParseException {

		// To read the data from key board

		int choice = 0;
		Scanner sc = new Scanner(System.in);
		StudentMapDemo sd = new StudentMapDemo();

		while (choice < 13) {
			System.out.println("Student Operations");
			System.out.println("========================");
			System.out.println("1.Add Student");
			System.out.println("2.Get Student");
			System.out.println("3.Delete Student");
			System.out.println("4.Update Student");
			System.out.println("5.Show All Students");
			System.out.println("6.Show Number of Students");
			System.out.println("7.Show Students Sorted by Student Id");
			System.out.println("8.Show Students Sorted by Student NAme");
			System.out.println("9.Show Students Sorted by Student MArks");
			System.out.println("10.Show Students Sorted by Student Age");
			System.out.println("11.Show Students Sorted by Student Email");
			System.out.println("12.Show Students Sorted by Student DOB");
			System.out.println("===========================");
			System.out.println("Enter the Choice");
			System.out.println("===========================");

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Student Id,Name,Marks,age,email and dob (dd-MM-yyyy)");

				Student student = new Student(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.next(),
						sc.next());

				sd.addStudent(student);
				break;

			case 2:
				System.out.println("Enter Student Id :");

				sd.showStudent(sc.nextInt());

				break;

			case 3:
				System.out.println("Enter Student Id :");

				sd.deleteStudent(sc.nextInt());

				break;

			case 4:
				System.out.println("Enter Student Id,Name,Marks,age,email and dob (dd-MM-yyyy)");

				student = new Student(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.next(), sc.next());

				sd.updateStudent(student);
				break;

			case 5:

				sd.showAllStudents();
				break;
			case 6:

				sd.showNumberOfStudents();
				break;
			case 7:

				sd.showAllStudentsSortedByStudentId();
				break;
			case 8:

				sd.showAllStudentsSortedByStudentName();

				break;
			case 9:

				sd.showAllStudentsSortedByStudentMarks();
				break;
			case 10:

				sd.showAllStudentsSortedByStudentAge();
				break;
			case 11:

				sd.showAllStudentsSortedByStudentEmail();
				break;
			case 12:

				sd.showAllStudentsSortedByStudentDob();
				break;

			default:
				return;
			}// switch

		} // while

	}// main

}// class
