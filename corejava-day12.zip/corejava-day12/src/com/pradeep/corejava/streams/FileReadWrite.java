package com.pradeep.corejava.streams;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileReadWrite {

	void write() {

		try (
				// to read the data from kb
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				// to writee the data in a file
				FileOutputStream fos = new FileOutputStream("data.txt");) {

			System.out.println("Enter the data and use @ at the end to save the contnets");

			char ch;

			while ((ch = (char) br.read()) != '@')
				fos.write(ch);

			System.out.println("File Saved successfully....");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}//write

	void read() {

		
		try (FileInputStream fis=new FileInputStream("data.txt")) {
			
			int ch=0;
			
			System.out.println("File Contents\n=====================\n");
			
			while((ch=fis.read())!=-1)
              System.out.print((char)ch);			
			
			
			System.out.println("File reading over...");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
	}

	public static void main(String[] args) {

		FileReadWrite f=new FileReadWrite();
		
		f.write();
		f.read();
		
		
	}
}
