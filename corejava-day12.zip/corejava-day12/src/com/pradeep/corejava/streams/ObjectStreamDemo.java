package com.pradeep.corejava.streams;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/*
 
Serialization
-------------
It is a mechanism of converting the object into stream

Deserialization
-------------===
It is a mechanism of reading the object from stream
 
  
 
 *
 */

class Student implements Serializable {

	private int id;
	private String name;
	private double marks;
	private int age;

	public Student() {
	}

	public Student(int id, String name, double marks, int age) {
		this.id = id;
		this.name = name;
		this.marks = marks;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", marks=" + marks + ", age=" + age + "]";
	}

}

public class ObjectStreamDemo {

	void write() {

		try (
				// to read the data from kb
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				// to writee the data in a file
				FileOutputStream fos = new FileOutputStream("data2.txt");
				ObjectOutputStream oos = new ObjectOutputStream(fos);

		) {

			System.out.println("Enter Student Id");
			int id = Integer.parseInt(br.readLine());
			System.out.println("Enter Student name");
			String name = br.readLine();
			System.out.println("Enter Student marks");
			double marks = Double.parseDouble(br.readLine());
			System.out.println("Enter Student age");
			int age = Integer.parseInt(br.readLine());

			Student student = new Student(id, name, marks, age);

			oos.writeObject(student);

			System.out.println("Student object svaed succesfully");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}// write

	void read() {

		try (FileInputStream fis = new FileInputStream("data2.txt");

				ObjectInputStream ois = new ObjectInputStream(fis);

		) {
			System.out.println("Student Details \n=====================\n");

			Student s = (Student) ois.readObject();

			System.out.println(s);

			System.out.println("File reading over...");

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		ObjectStreamDemo f = new ObjectStreamDemo();

		f.write();
		f.read();

	}
}
