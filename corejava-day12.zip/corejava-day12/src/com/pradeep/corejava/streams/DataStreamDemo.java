package com.pradeep.corejava.streams;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class DataStreamDemo {

	void write() {

		try (
				// to read the data from kb
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				// to writee the data in a file
				FileOutputStream fos = new FileOutputStream("data1.txt");
				DataOutputStream dos=new DataOutputStream(fos);
				
				) {

			
			System.out.println("Enter Student Id");
			int id=Integer.parseInt(br.readLine());
			System.out.println("Enter Student name");
			String name=br.readLine();
			System.out.println("Enter Student marks");
			double marks=Double.parseDouble(br.readLine());
			
			dos.writeInt(id);
			dos.writeUTF(name);
			dos.writeDouble(marks);
			
			System.out.println("Student data svaed succesfully");	
			
			
			
			

			System.out.println("File Saved successfully....");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}//write

	void read() {

		
		try (FileInputStream fis=new FileInputStream("data1.txt");
			
				DataInputStream dis=new DataInputStream(fis);
				
				) {
			
			int ch=0;
			
			System.out.println("Student Drtails \n=====================\n");
			
			System.out.println("Student Id   :"+dis.readInt());
			System.out.println("Student Name :"+dis.readUTF());
			System.out.println("Student Marks:"+dis.readDouble());
			
			
			System.out.println("File reading over...");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
	}

	public static void main(String[] args) {

		DataStreamDemo f=new DataStreamDemo();
		
		f.write();
		f.read();
		
		
	}
}
