package com.pradeep.corejava.streams;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileReadWrite1 {

	void write() {

		
		String s="Hello Student!!! This is Saii Tec I am a trainer here";
		
		try (FileWriter fw = new FileWriter("data3.txt");) {

			for(int i=0;i<s.length();i++)
			 fw.write(s.charAt(i));	
			
			
			System.out.println("File Saved successfully....");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}// write

	void read() {

		try (FileReader fr = new FileReader("data3.txt")) {

			int ch = 0;

			System.out.println("File Contents\n=====================\n");

			while ((ch = fr.read()) != -1)
				System.out.print((char) ch);

			System.out.println("File reading over...");

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		FileReadWrite1 f = new FileReadWrite1();

		f.write();
		f.read();

	}
}
