Stream
----------
			A stream represents flow of
			 data that travels from one place 
			to another place.
			
			keyboard->memory

            memory->monitor

			memory->printer

			memory->file
              
InputStream :-  Reads or recieves the data

OutputStream :- writes or sends the data

Every  stream is  represented as class in 
java.io package

	Note :-
	--------
InputStream  and OutputStream
-------------------------------------------

	To handle the data in the form of bytes 
	the abstract	classes (InputStream	and OutputStream) 
	are used. 
	
	
	System.in  => InputStream => Keyboard
	System.out => PrintStream => monitor
	System.err => PrintStream => monitor

	
	Reader  and Writer
-------------------------------------------

	To handle the data in the form of characters 
	the abstract	classes (Reader  and  Writer) 
	are used. 
	
