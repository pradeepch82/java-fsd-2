package com.pradeep.spring.bank.dao;

import java.util.ArrayList;
import java.util.List;

import com.pradeep.spring.bank.data.AccountMap;
import com.pradeep.spring.bank.model.Account;

public class MapAccountDaoImpl implements AccountDao {

	public MapAccountDaoImpl() {
		System.out.println("MapAccountDaoImpl  created successfully");
	}

	@Override
	public boolean addAccount(Account account) {
		return AccountMap.INSTANCE.getMap().put(account.getAccno(), account) == account;
	}

	@Override
	public boolean deleteAccount(int accno) {

		if (AccountMap.INSTANCE.getMap().containsKey(accno)) {
			AccountMap.INSTANCE.getMap().remove(accno);
			return true;
		}

		return false;
	}

	@Override
	public List<Account> findAllAccounts() {

		return new ArrayList<>(AccountMap.INSTANCE.getMap().values());
	}

	@Override
	public Account findAccount(int accno) {
		// TODO Auto-generated method stub
		return AccountMap.INSTANCE.getMap().get(accno);
	}

	@Override
	public boolean saveAccount(Account account) {

		if (AccountMap.INSTANCE.getMap().containsKey(account.getAccno())) {
			AccountMap.INSTANCE.getMap().put(account.getAccno(), account);
			return true;
		}

		return false;
	}

	public void myinit() {
		System.out.println("MapAccountDaoImpl Init Method..");
	}
	
	public void mydestroy() {
		System.out.println("MapAccountDaoImpl Destroy Method..");
	}
}
