package com.pradeep.spring.bank.presentation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pradeep.spring.bank.model.Account;
import com.pradeep.spring.bank.service.AccountService;

public class MainApp {

	private AccountService as;

	public MainApp() {

		System.out.println("=========MainApp created============");
	}

	public AccountService getAs() {
		return as;
	}

	public void setAs(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp setAs method....============");

	}

	public MainApp(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp param constructor....============");

	}

	public void addAccount(Account account) {

		if (as.addAccount(account))
			System.out.println("Account added successfully");
		else
			System.out.println("Problem in adding the account");

	}

	public void saveAccount(Account account) {

		if (as.saveAccount(account))
			System.out.println("Account update successfully");
		else
			System.out.println("Account doesnot exist");

	}

	public void deleteAccount(int accno) {

		if (as.deleteAccount(accno))
			System.out.println("Account deleted successfully");
		else
			System.out.println("Account doesnot exist");

	}

	public void findAccount(int accno) {

		Account a = as.findAccount(accno);

		if (a != null)
			System.out.println("Account Details \n\n================" + a);
		else
			System.out.println("Account doesnot exist");

	}

	public void findAllAccounts() {
			System.out.println("Account Details \n\n================");
			
			for(Account a:as.findAllAccounts())
               System.out.println(a);  
	}
	
	public void myinit() {
		System.out.println("Main App Init Method..");
	}
	
	public void mydestroy() {
		System.out.println("Main App Destroy Method..");
	}
	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext c = new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Spring Container created..");
		
		MainApp a = c.getBean(MainApp.class);
		a.findAllAccounts();
		
		c.close();
		
		
	}

}
