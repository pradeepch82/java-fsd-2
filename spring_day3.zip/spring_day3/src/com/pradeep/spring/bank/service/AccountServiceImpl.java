package com.pradeep.spring.bank.service;

import java.util.List;

import com.pradeep.spring.bank.dao.AccountDao;
import com.pradeep.spring.bank.model.Account;

public class AccountServiceImpl implements AccountService{

	private AccountDao accountDao;

	public AccountServiceImpl() {
		System.out.println("............AccountServiceImpl created...........");
	}

	public AccountServiceImpl(AccountDao accountDao) {

		this.accountDao = accountDao;
		System.out.println("............AccountServiceImpl param constructor...........");
	}

	public AccountDao getAccountDao() {
		return accountDao;
	}

	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
		System.out.println("............AccountServiceImpl setAccountDao method...........");

	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.addAccount(account);
	}

	@Override
	public boolean deleteAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.deleteAccount(accno);
	}

	@Override
	public List<Account> findAllAccounts() {
		// TODO Auto-generated method stub
		return accountDao.findAllAccounts();
	}

	@Override
	public Account findAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.findAccount(accno);
	}

	@Override
	public boolean saveAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.saveAccount(account);
	}

	public void myinit() {
		System.out.println("Acc Service Impl Init Method..");
	}
	
	public void mydestroy() {
		System.out.println("Acc Service Impl Destroy Method..");
	}
}
