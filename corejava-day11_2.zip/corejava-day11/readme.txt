/*

what is a bug ?
----------------------

	The error commited in a program  is called bug.

	Removing error is called as debugging.

	There are three types of errors

	1.Compile time errors
	-----------------------------
				These errors represent inprpoer use of syntax 
				or grammer language.

				These errors are detected by compiler

class Err
{
public static void main(String s[])
{
System.out.println("Hello")
}
}

2.Runtime errors
-----------------------
			These are the errors occurs due to illegal	operations.
			These errors are detected by JVM

class Err
{
public static void main()
{
System.out.pritln("Hello");
}
}

Most of run time errors are called exceptions

Removing runtime errors is difficult.

3. Logical errors
-----------------------
		These errors are commited in a logic of the program.
		
		Logical errors are not detected by compiler or JVM.
		
        Programmer is responsible for logical errors.
		
class Err
{
public static void main(String s[])
{
float sal=5000f;

sal=sal*10/100;

System.out.println("Salary="+sal);
}
}

By compairing o/p with maually calculated 
results you can detect/suspect  logical errors

Exception
----------------
			An  Exception is rutime error.

What are checked and uchecked exceptions?
----------------------------------------------------
The exceptions which are caught 
by java compiler are called as checked 
excption 

The exceptions which are caught by JVM
are called as unchecked excption 


What is the difference between error and
Exception ?
------------------------------------------------------------------
An exception is an error which is
handled by prorammer

The errors cannot be handled 
by programmer

Every exception is represented as
class in java
 
									java.lang
									       |
                                    Throwable
                                            |              
			 -----------------------------------------------
			 |                                                               |
        Error		                                              Exception
            |                                                                |
--------------------                                    ---------------------
|    |    |   |      |      |                                     |       |    |    |      |    |
All error classes                                 All Exception classes



Exception is a super class for all 
exception subclassees

Error is a super class for all 
error subclasses  

Any  abnormal event in the program is called
an exception



Exception  handeling
----------------------------

When there is an exeception in java the program
will be terminated in the middle,so already opened files
or databases might not be closed,leading to destruction
of data on the system.

							In case of an Exception
	programmer has to perform the follwowig tasks.
	
	1.Display exception details

	2.Display message to the user

	3.Close the files in databases

	Performig the above task is nothing but Exception 
	handeling.

	Exception handeling is done by try,catch,& finally block


syntax:-
----------			
				try
				{
				statements;
				}
				catch(Exception obj)
				{
				statements;
				}
				finally
				{
				statements;
				}


1.  try block contains the statements which are examined      for any exception

2.When there is an exception JVM stores exception details in    stack  and jumps into catch block.

		In catch block we should display exception details 
		to the user & also any general message.

3.finally block contains the statements that executes even
  though there is exception or not.

try-catch-finally
try-catch
try-finally


Checked Exception  :Detected by Java Compiler ,u must hanlde or propogate

ClassNotFoundExcpetion
InstantiationException
IllegalAccessException
FileNotFoundException
InterruptedException
IOException


Uncheked Exception :Detcted by JVM and no need to handle

   RuntimeException

1.ArithmeticException
2.ArrayIndexOutOfBoundsException
3.StringIndexOutOfBoundsException
4.NullPointerException




2.User defined Exception
----------------------------------
These Exceptions are created by user


1.Write a class that extends Exception class

2.write default costructor in the class

3.write a parameterised constructor with string as a    parameter

4.create an object to your class and throw it out using
  throw clause when required

Collection Framework  (Group of classes and interface)  :java.util
=======================================================

Arrays.toString()
Random

Group of elements stored ate some place.
    
Group of students

1.Get all Students
2.Get Student By Id
3.Get Student By Class NAme
4.Sort students by Name
5.Sort students by Age
6.Delete students by Id
7.Update students by Id
8.Get Number of Students
9.Add Student


Array :Collection of elements of similar type
===== 

Static in nature


Sorting
==========
java.lang.Comparable<T>
java.util.Comparator<T>





















