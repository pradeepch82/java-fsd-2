package com.pradeep.corejava.collections;

import java.util.Arrays;

class Emp implements Comparable<Emp>{
	private int id;
	private String name;
	
	public Emp(int id,String name) {
	this.id=id;
	this.name=name;
	}
	
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public int compareTo(Emp o) {

		
		//return id-o.getId(); //id basis
		return name.compareTo(o.getName()); //id basis
		
	}
	
	
	
	@Override
	public String toString() {
		return "["+id+" "+name+"]";
	}
}


public class SortDemo {
public static void main(String[] args) {

	String []arr1= {"RAM","RAHIM","DAVID"};
	Integer []arr2= {12,11,45};
	Emp emps[]= {new Emp(112,"RAJ"),new Emp(4453,"AMEYA"),new Emp(563,"SUNIL")};
	
	
	
	System.out.println("Before sorting");
	System.out.println("========================");
	System.out.println("Arr1 :"+Arrays.toString(arr1));
	System.out.println("Arr2 :"+Arrays.toString(arr2));
	System.out.println("emps :"+Arrays.toString(emps));
	
	
	
	Arrays.sort(arr1);
	Arrays.sort(arr2);
	Arrays.sort(emps);
	
		
	
	System.out.println("After sorting");
	System.out.println("========================");
	System.out.println("Arr1 :"+Arrays.toString(arr1));
	System.out.println("Arr2 :"+Arrays.toString(arr2));
	System.out.println("emps :"+Arrays.toString(emps));
		
	
	
	
	
	
}
}
