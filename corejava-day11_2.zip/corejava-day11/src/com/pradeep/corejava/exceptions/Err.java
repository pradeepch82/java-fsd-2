package com.pradeep.corejava.exceptions;

public class Err {
public static void main(String[] args) {
	System.out.println("Welcome To Java");
	main(args);
}
}
