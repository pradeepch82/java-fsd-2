package com.pradeep.corejava.exceptions;

class SpeedOutOfRangeException extends Exception{

	public SpeedOutOfRangeException(String message) {
		super(message);//calls Super class parameterized constructor
		
	}
	
}



public class TestSpeed {

	private static final int MAX=80;
	private static final int MIN=40;

	
	static void testSpeed(int speed)throws SpeedOutOfRangeException {
		
		try {
			System.out.println("In testSpeed  try...");
			if(speed<MIN)
				throw new SpeedOutOfRangeException("You r running below range at "+speed+"/ hour");
			if(speed>MAX)
				throw new SpeedOutOfRangeException("You r running above range at "+speed+"/ hour");
				
			System.out.println("You running good at speed :"+speed+"/hour");
		
		}
		catch(Exception e) {
		System.out.println("In test Speed catch block");	
		 throw e;
		}
		
			
		
	}
	
	public static void main(String[] args) {
		
		
		try {
			System.out.println("In main try...");
			testSpeed(89);
		} catch (SpeedOutOfRangeException e) {
			System.out.println("In main catch block");
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
}
