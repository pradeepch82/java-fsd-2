package com.pradeep.coerjava.basics;

import java.text.NumberFormat;
import java.util.Calendar;

/*
 
 
3.Factory method
-----------------------
Factory method is method  which returns the object of that class to which it belongs

//Class c=Class.forName("java.lang.String");


Calendar c=Calendar.getInstance();

NumberFormat nf=NumberFormat.getNumberInstance();


  
 * */


public class FactoryMethodDemo {
public static void main(String[] args) {
	
	double n=5637373.44455364575675;
	
	
	Calendar c=Calendar.getInstance();
	
	NumberFormat nf=NumberFormat.getNumberInstance();
	
	nf.setMinimumFractionDigits(10);
	nf.setMaximumFractionDigits(3);
	
	String s=nf.format(n);
	
	System.out.println("Non Formated Number :"+n);
	System.out.println("Formated Number     :"+s);
	
	
	
	
	
}
}
