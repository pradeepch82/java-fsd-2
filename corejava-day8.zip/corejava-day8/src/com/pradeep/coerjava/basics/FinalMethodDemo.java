package com.pradeep.coerjava.basics;

final class A{
	
}

class B extends A{
	
}




public class FinalMethodDemo {
public static void main(String[] args) {
	
}
}
