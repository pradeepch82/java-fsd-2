package com.pradeep.coerjava.basics;

/*
 	Instance Methods
 	=================
 	
 	These methods which acts on instance members of the class are called instance methods.

			instance methods can be  called by using 

			objectname.methodname();


	a.Accessor  method
	--------------------------
		Accessor methods only reads and display the
		data of object.


	2.Mutator  method
		---------------------
		Mutator method not only read and  display but
		also modifies the 	data of object.

 
 
  
  */


class Student{

//instance variable	
private int id;
private String name;

public Student() {
}

public Student(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + "]";
}
	



}






public class InstanceMethodDemo {
public static void main(String[] args) {
	
	Student s=new Student();
	
	s.setId(101);
	s.setName("Pradeep");
	
	System.out.println("Id    :"+s.getId());
	System.out.println("Name  :"+s.getName());
	
	
	System.out.println(s);
	
	
	
}
}
