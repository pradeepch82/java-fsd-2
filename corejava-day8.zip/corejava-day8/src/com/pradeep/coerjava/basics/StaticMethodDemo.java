package com.pradeep.coerjava.basics;
/*
2.Static method
-------------------
Static method is a method which can be called without
	creating an object to the class.

	Static method can access only static data members

	static is a keyword to declare static method.

    static int a=10;
   
	static void display()
	{
	----
	----
	}

static method can be called by 

			Classname.methodname();

*/

class Sample{

	int a=100; //instance variable
	static int b=200; //static variable
	
	
	public static void display() {
		System.out.println("In display method...");
		System.out.println("a :"+new Sample().a);
		System.out.println("b :"+b);
	}
	
}






public class StaticMethodDemo {

	public static void main(String[] args) {
	
		Sample s1=new Sample();   // a=10
		Sample s2=new Sample();   // a=10
		Sample s3=new Sample();   // a=10
		
		s1.a=200;
		s1.b=23000;
		
		System.out.println("s1 :a "+s1.a+"     b: "+s1.b);
		System.out.println("s2 :a "+s2.a+"     b: "+s2.b);
		System.out.println("s3 :a "+s3.a+"     b: "+s3.b);
		
       System.out.println(Sample.b);

		Sample.display();
		
	}
}
