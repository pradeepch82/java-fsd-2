Types of Methods
==================
Method
-------------

Method is a group of statements to perform a particular task.


Types of methods
------------------------

1.Instance method
---------------------------
	These methods which acts on instance members of the class are called instance methods.

			instance methods can be  called by using 

			objectname.methodname();


	a.Accessor  method
	--------------------------
		Accessor methods only reads and display the
		data of object.


	2.Mutator  method
		---------------------
		Mutator method not only read and  display but
		also modifies the 	data of object.




2.Static method
-------------------
Static method is a method which can be called without
	creating an object to the class.

	Static method can access only static data members

	static is a keyword to declare static method.

    static int a=10;
   
	static void display()
	{
	----
	----
	}

static method can be called by 

			Classname.methodname();






3.Factory method
-----------------------
Factory method is method  which returns the object of that class to which it belongs

4.Final method
------------------------
final class A{}
final void show(){}
final int MAX=10;


final class A{
void a(){}
void b(){}
void c(){}
}

final key word before class prevents the inheritance
final methods can not be overridden


OverLoading and Overriding Rules
=================================

Polymorphism
-----------------
Poly-  many
morphism -forms

			  It is an ability to take more than one form

             If same method performs different tasks is called   
			 polymorphism

Runtime/ Dynamic polymorphism
------------------------------------------------
A polymorphism exhibited at run time is called as
'Dynamic Polymorphism'

In dynamic polymorphism method call is not linked 
with method body at compile time.

 .This means method call is linked with method body 
at run time.This is called as dyamic polymorphism
or  dynamic binding or late binding
       
Example
method overloading
method overriding


Method overloading
------------------------
             If two or more methods are written with same 
			 name but with difference in parameters is called as
			 method overloading.

			 JVM can identify the methods seprately by 
			 the difference in their parameters at run time.
			 
			 The difference may be in

1. In  number of arguments
---------------------------------

void sum(int a,int b);
void sum(int a,int b,int c);

2.In the datatypes of parameters
-----------------------------------------
void sum(int a ,int b);
void sum(float a ,float b);

3.In the sequence of arguments
-------------------------------------
void display(int a,char c);
void display(char c,int a);

Method signature
----------------------
		Any one of the above difference is called as
		method signature.Method signature uniquely
		identify a method by difference in parameters.
	

Method overriding
------------------------
Writing two methods with same name and same
method signature in super class and subclass
is called method overriding

Generally sub class method will override super class method.




