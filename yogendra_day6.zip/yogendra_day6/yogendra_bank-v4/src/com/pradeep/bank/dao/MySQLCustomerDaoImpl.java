package com.pradeep.bank.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pradeep.bank.data.CustomerMap;
import com.pradeep.bank.model.Customer;

@Repository
//@Component("mySQLCustomerDaoImpl")
public class MySQLCustomerDaoImpl implements CustomerDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public MySQLCustomerDaoImpl() {
		System.out.println("========MySQLCustomerDaoImpl  created =============");
	}

	@Override
	public boolean saveCustomer(Customer customer) {

		return jdbcTemplate.update("INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?,?)", customer.getCustomerId(),
				customer.getName(), customer.getPan(), customer.getMobile(), 123, customer.getDateOfBirth(),
				customer.getAddress()) == 1;

	}

	@Override
	public boolean updateCustomer(Customer customer) {

		return jdbcTemplate.update("UPDATE CUSTOMER SET MOBILE=?, ADDRESS=? WHERE CUSTOMERID=?", customer.getMobile(),

				customer.getAddress(), customer.getCustomerId()) == 1;

	}

	@Override
	public boolean deleteCustomer(int customerId) {
		return jdbcTemplate.update("DELETE FROM CUSTOMER WHERE CUSTOMERID=?",customerId) == 1;

	}

	@Override
	public List<Customer> findAllCustomers() {
		return jdbcTemplate.query("SELECT * FROM CUSTOMER",new CustomerRowMapper());
	}

	@Override
	public Customer findCustomer(int customerId) {
			return jdbcTemplate.queryForObject("SELECT * FROM CUSTOMER WHERE CUSTOMERID=?", new CustomerRowMapper(), customerId);
	}

}
