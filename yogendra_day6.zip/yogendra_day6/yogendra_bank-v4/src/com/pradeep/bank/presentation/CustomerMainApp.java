package com.pradeep.bank.presentation;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.pradeep.bank.model.Customer;
import com.pradeep.bank.service.CustomerService;


@Controller
//@Component
public class CustomerMainApp {

	
	@Autowired
	private CustomerService cs; // dependency

	public CustomerMainApp() {
		System.out.println("====CustomerMainApp  created==========");
	}

	
	
 	/*	@Autowired
	 * public CustomerMainApp(CustomerService cs) // constructor injection { this.cs
	 * = cs; System.out.println("====CustomerMainApp  param constructor==========");
	 * }
	 * 
	 * 
	 * 
	 * public void setCs(CustomerService cs)// setter injection { this.cs = cs;
	 * System.out.println("====CustomerMainApp  setCs method...==========");
	 * 
	 * }
	 */
	public void addCustomer(Customer customer) {

		if (cs.saveCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] added successfully");
		else
			System.out.println("Problem in insertion");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] updated successfully");
		else
			System.out.println("Customer doesn't exist");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with Id [" + customerId + "] deleted successfully");
		else
			System.out.println("Customer doesn't exist");

	}

	public void showCustomer(int customerId) {

		Customer c = cs.findCustomer(customerId);

		if (c != null)
			System.out.println("Customer with Id [" + customerId + "] Details\n====================" + c);

		else
			System.out.println("Customer doesn't exist");

	}

	public void showAllCustomers() {

		System.out.println("============================================================");
		System.out.println("              Customer Details                              ");
		System.out.println("============================================================");
		for (Customer c : cs.findAllCustomers())
			System.out.println(c);
	}

	
	@PostConstruct
	public void init() {
		System.out.println("Customer Main App Initialized.....");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Customer Main App destroyed.....");
	}
	
	
	
	public static void main(String[] args) {

		// create a Spring Container
         
		//XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));
         
	    ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans-jdbc.xml");
	        
        System.out.println("Spring container created....");
        

        //get bean from  container
        
          //get bean by type if only one bean of specific type
         //CustomerMainApp cma=c.getBean(CustomerMainApp.class);
         
        //get bean by id when multiple beans of same type
       CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
       System.out.println("Before Updataion");
		System.out.println("==============================================================");

		
		cma.showAllCustomers();

		
		
		//Insert 2 records
		
		cma.addCustomer(new Customer("sachin sharma", "amxoi9876e", "7789277654", null,new Date(2011,11,11),"Pune"));
		cma.addCustomer(new Customer("rajat sharma", "amxoi9876e", "7789277654", null,new Date(2011,11,11),"Pune"));
		
		cma.deleteCustomer(103);
		Customer c1=new Customer();
		
		c1.setCustomerId(101);
		c1.setAddress("Pune");
		c1.setMobile("9878787878");
		cma.updateCustomer(c1);
		

		System.out.println("After Updataion");
		System.out.println("==============================================================");


		cma.showAllCustomers();

		// shutdown the container
		c.registerShutdownHook();
	
		
	}

}
