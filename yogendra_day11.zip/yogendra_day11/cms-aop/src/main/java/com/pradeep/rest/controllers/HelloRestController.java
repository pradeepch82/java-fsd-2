package com.pradeep.rest.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/hello")
public class HelloRestController {

	public HelloRestController() {
		System.out.println("===========HelloRestcontroller created....=======");
	}

	@GetMapping
	public String helloGet() {
		return "HelloRestController  : GET";
	}

	@PutMapping
	public String helloPut() {
		return "HelloRestController  : PUT";
	}

	@PostMapping
	public String helloPost() {
		return "HelloRestController  : POST";
	}

	@DeleteMapping
	public String helloDelete() {
		return "HelloRestController  : DELETE";
	}

	@PatchMapping
	public String helloPatch() {
		return "HelloRestController  : PATCH";
	}

}
