package com.example.demo;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.encrypt.BytesEncryptor;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BCryptPasswordEncoder b=new BCryptPasswordEncoder();
		
		System.out.println("RAM    "+b.encode("RAM"));
		System.out.println("RAHIM  "+b.encode("RAHIM"));
		System.out.println("DAVID  "+b.encode("DAVID"));
		
		
		
	}

}
