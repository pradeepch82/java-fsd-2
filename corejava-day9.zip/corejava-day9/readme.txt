Stream
----------
			A stream represents flow of
			 data from one place 
			to another place.
			
			keyboard->memory

            memory->monitor

			memory->printer

			memory->file
              
InputStream :-  Reads or recieves the data

OutputStream :- writes or sends the data

Every  stream is  represented as class in 
java.io package

	Note :-
	--------
InputStream  and OutputStream
-------------------------------------------

	To handle the data in the form of bytes 
	the abstract
	classes (InputStream	and OutputStream) 
	are used. 
	
	
	System.in  => InputStream => Keyboard
	System.out => PrintStream => monitor
	System.err => PrintStream => monitor
	
	
1.Scanner
2.Relationsship between classes
  has  A
  is   A
  uses A

  Generalization
  Specilization
  
Association
    1.Agregation  -losely typed association
    2.Composition -tightly coupled association




class Employee{

private int id;
private String name;
private double salary;
private Address address;

}



class Address{
int flatNo;
String buildName;
String area;
String city;
}





Aggregation
============

Library has Books
Car has tape recorser
Building has generator

Composition
===========
Library has Members -> 
Car has engine
Building has flat




Assignment
===========
1.Write a Program to accept 3 numbers from user and display maximum number among 3.
2.Write a Program to accept 3 numbers from user and display minimum number among 3.
3.Write a Program to accept day number form from user and display name of the day
   Ex.
    1 -Monday
    2-Tuesday.. 

4.Write a Program to accept monthnumber form from user and display name of the month
   Ex.
    1 -January
    2 -Februaray 
   








	
	
	