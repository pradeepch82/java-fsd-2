package com.pradeep.corejava.basics;

import java.util.Scanner;

public class KeyInputDemo {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter string value:");
	//String s1=sc.next();//read without space
	String s1=sc.nextLine();//read with space
	System.out.println("Enter byte value:");
	byte b=sc.nextByte();
	System.out.println("Enter short value:");
	int s=sc.nextShort();
	System.out.println("Enter int value:");
	int i=sc.nextInt();
	System.out.println("Enter long value:");
	long l=sc.nextLong();
	System.out.println("Enter float value:");
	float f=sc.nextFloat();
	System.out.println("Enter doubel value:");
	double d=sc.nextDouble();
	System.out.println("Enter boolean value:");
	boolean b1=sc.nextBoolean();
	

	
	System.out.println(" b  :"+b);
	System.out.println(" s  :"+s);
	System.out.println(" i  :"+i);
	System.out.println(" l  :"+l);
	System.out.println(" f  :"+f);
	System.out.println(" d  :"+d);
	System.out.println(" b  :"+b1);
	System.out.println(" s  :"+s1);
		
	
}
}
