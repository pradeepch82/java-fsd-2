
Thread
--------------
			Thread represents a process or execution
			of the statement.
			
			JVM uses internally threads to run a java
			programs.

			Every java program will have  a
			thread
				
Handling the task is of two types

1.Single tasking
---------------------
Processing only one task at a time is 
called as Single tasking. 

In single tasking processing time is more.
Micro processor will be ideal for most of the time.
The time of processor will not be used effectively.

2.Multitasking
---------------------
Processing different tasks at a time is called Multitasking.
			
		After completing last task coming to first task is called Round Robin.

1. Process based multitasking
----------------------------------------
Executing  several programs simultaneously is called process based multitasking.

2. Thread based multitasking
----------------------------------------
Executing  several parts of  the same programs simultaneously is called Thread based
 multi tasking/multithreading.

IIQ
-------
Where the threads are useful?

1.Threads are used in animation & creating the games.

2.Threads are used in server to handle 100000's of clients..

In multithreading the processor time is used in optimum way 

we can create threads by using Thread class or Runnable iterface


Creating a thread
----------------------------
1.  Extend Thread class or implement Runnable
     interface.

	 Example

	 class MyThread extends Thread{...........}

	class MyThread implements Runnable{...........}

2.Write run method with code inside it

		public void run()
		{-}

3.Create an object to class  and attach a thread to it.

MyThread obj=new MyThread();

Thread t=new Thread(obj);

4. Call run method 
		t.start();



/*
How can you stop the thread in the middle ?
1. Create a boolean variable and initialize it as false

boolean stop=false;

2.Whenever this variable becomes true  thread should be    stop.

3.Whenever the user pressses enter button make    boolean variable true

*/


/*

What is the Difference  between extends  Thread 
and implements Runnable ?
->
		Functionally both are same.
		implements  Runnable is advantageous because 
		when we implement Runnable interface still
		there is a scope for extending another class.

class MyThread implements Runnable extends Frame
{..}
*/
// 2 threads acting  on 2 different objects


/*
MIIQ

What is Thread Synchronization?
------------------------------------------
	When a thread is processing an object,
	keeping other threads waiting till the first
	thread comes out of the object is called Thread	synchronization.

*/
