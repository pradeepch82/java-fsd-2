package com.pradeep.corejava.basics;


class Reserve implements Runnable
{

int available=1;

int wanted;


public Reserve(int i)
{
wanted=i;
}


public void run()
{

System.out.println(Thread.currentThread().getName()+"  booking the ticket");

try
{
Thread.sleep(5000);

}

catch(InterruptedException ie){}
synchronized(this)
{
System.out.println("Number of births available :"+available);

if(available>=wanted)
{

System.out.println(wanted +" berths reserved for "+Thread.currentThread().getName());
available=available-wanted;

}
else
System.out.println("Sorry ,no berths  to reserve for "+Thread.currentThread().getName());
}//synchronized

}//run

}//class


class Sync
{
public static void main(String args[])
{
//Create one object to reserve class and tell 1 berth is needed

Reserve obj=new Reserve(1);
//create two threads and attach them to sam object

Thread t1=new Thread(obj);
Thread t2=new Thread(obj);
Thread t3=new Thread(obj);


 //give names to threads

t1.setName("Ram");
t2.setName("Rahim");
t3.setName("David");


 //run the Threads
 t1.start();
 t2.start();
 t3.start();
 }
 }

 