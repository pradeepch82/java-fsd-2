package com.pradeep.corejava.basics;




//creating thread

import java.io.*;

class MyThread extends Thread
{

boolean stop=false;

public void run()
{
for(int i=0;i<10;i++)
{
	
System.out.println(Thread.currentThread().getName()+"  prints :"+i);
if(stop)
	return;

try {
	Thread.sleep(1000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}//for
}//run
}//Mythread

class ThreadDemo
{
public static void main(String args[])throws IOException, InterruptedException
{
	MyThread obj1=new MyThread();
	MyThread obj2=new MyThread();

	obj1.setName("Ram");
	obj2.setName("Mohan");
	
	obj1.start();  //internally calls run metod
	obj1.join(5000);
	
	obj2.start();  //internally calls run metod
//obj.run();
System.in.read();
obj1.stop=true;
obj2.stop=true;
}
}

	
