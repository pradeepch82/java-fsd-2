package com.pradeep.corejava.basics;

/*

Thread
--------------
			Thread represents a process or execution
			of the statement.
			

			JVM uses internally threads to run a java
			programs.

			Every java program will have  a
			thread
				
java.lang.Thread
-------------------------

Thread Class methods
-------------------------------
1.To know the currently running Thread
------------------------------------------------------

	Thread t=Thread.currentThread();

2. To start a Thread
-----------------------------
		t.start();

3.To stop execution of thread for a specified time.
--------------------------------------------------------

		Thread.sleep(millisecond);

4.To execute some code using  a thread,write it in  run method
------------------------------------------

public void run()
{
code
}

5.To get the name of Thread
-------------------------------------

		String  name=t.getName();

6.To set a new name to a thread
-------------------------------------------
			t.setName("name");

7.To get priority of thread
------------------------------------

   int  priority_no=t.getPriority();
   
8.To set the priority of thread
---------------------------------------

		t.setPriority(int priority);

The priority no. costants ar given below

Thread.MAX_PRIORITY value is 10
Thread.MIN_PRIORITY value is 1
Thread.NORM_PRIORITY value is 5

9. To test if a thread is still alive are not
------------------------------------------------------
                     boolean b=t.isAlive()

10.To wait till a Thread dies
----------------------------------------
				t.join();
*/
class Current
{
public static void main(String args[])
{

System.out.println("First Statement");

Thread t=Thread.currentThread();

t.setName("First");
t.setPriority(10);
System.out.println(t);
System.out.println("Thread Name	:  "+t.getName());
System.out.println("ThreadGroup Name  :  "+t.getThreadGroup());
System.out.println("Thread prioity  :  "+t.getPriority());
}
}

/*

Handeling the task is of two types

1.Single tasking
---------------------
Processing only one task at atime is 
called as Single tasking. 

In single tasking processing time is more.
Microprocssor will be ideal for most of the time.
The time of processor will not be used effectively.


2.Multitasking
---------------------
			After completing last task coming to first task is called Round Robin.


1. Process based multitasking
----------------------------------------
Executing  several programs simultaneously is called procss based multitaskig.

2. Process based multitasking
----------------------------------------
Executing  several programs simultaneously is called procss based multitaskig.

2. Thread based multitasking
----------------------------------------
Executing  several parts of  programs simultaneously is called Thread based multitaskig.


IIQ
-------
Where the threads are useul?

1.Threads are used in animation & creating the games.

2.Threads are used in server to handle 100000's of 
clients.& creating the games.

In multithreadig the processor time is used in optimum way. 

we can create threads by using Thread class or 
Runnable

1.Creating a thread
----------------------------
1.  Extend Thread class or implement Runnable
     interface.

	 Example

	 class MyThread extends Thread{...........}

	class MyThread implements Runnable{...........}

2.Write run method with code inside it

		public void run()
		{
		--
		--
		}

3.Create an object to class  and attach a thread to it.

MyThread obj=ew MyThread();

Thread t=new Thread(obj);

4. Call run method 

		t.start();

*/
