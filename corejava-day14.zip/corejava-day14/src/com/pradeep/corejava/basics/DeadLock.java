package com.pradeep.corejava.basics;
/*
DeadLock Thread
-----------------------

When a thread is waiting for an object 
which has ben aleady locked by other thread  and
other thread is waiting for the first  
object which is locked by first thread.

     Both the threads will be in waiting state only .
This means Threads are in a state called DeadLock.

	In DeadLock ,first thread will wait for  object
	to be released by second thread and second thread will wait 
	for the object to be released by  first thread.. 
    The threads will not release the object,till the 
	other object is available.They  will go into
	deadlock state.

	The programmer should avoid deadlock by	taking caution
*/

class CancelTicket extends Thread 
{
   Object train,comp;

  //parameterised costructor
  
  CancelTicket (Object train,Object comp)
    {
     this.train=train;
     this.comp=comp;
    }
  
   public void run()
   {
	  synchronized(comp)
     {
       System.out.println("CancelTicket locked the Compartment");
      try
      {
         Thread.sleep(2000);
	  }
catch(InterruptedException ie){}
System.out.println("CancelTicket  is now waiting to lock train");
	synchronized(train)
	{
	System.out.println("CancelTicket has locked the train");
	}
 }
}
}



class BookTicket extends Thread
{

Object train,comp;

BookTicket(Object train,Object comp)
{
this.train=train;
this.comp=comp;
}

public void run()
{

 synchronized(train)
 {
  System.out.println("BookTicket has locked the train");
  try
   {
   Thread.sleep(2000);
   }
catch(InterruptedException ie){  }

System.out.println("BookTicket is now waiting to lock the compartment");

synchronized(comp)
  {
System.out.println("BookTicket has locked the compartment");
  }
}
}
}

class DeadLock
{
public static void main(String args[])throws Exception
{

//take comp and train as objects

Object train=new Object();
Object comp=new Object();

//crat object to cancl ticket and book ticket

CancelTicket obj1=new CancelTicket(train,comp);

BookTicket obj2=new BookTicket(train,comp);

//create 2 threads and attach to obj1 and obj2

Thread t1=new Thread(obj1);
Thread t2=new Thread(obj2);
//run the threads
t1.start();
t2.start();
}
}
