package com.pradeep.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.spring.dao.AccountDao;
import com.pradeep.spring.model.Account;


@Service
public class AccountServiceImpl implements AccountService {
	
	
    @Autowired
	//@Qualifier("mySqlAccountDaoImpl")
	private AccountDao accountDao;

	public AccountServiceImpl() {
		System.out.println("AccountServiceImpl created......");
	}
    
	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
		System.out.println("AccountServiceImpl  :setAccountDao method..........");
	}

	public AccountServiceImpl(AccountDao accountDao) {
		this.accountDao = accountDao;
		System.out.println("AccountServiceImpl  :param constructor.......");
	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.addAccount(account);
	}

	@Override
	public boolean updateAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.updateAccount(account);
	}

	
	@Override
	public boolean deleteAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.deleteAccount(accno);
	}

	@Override
	public Account getAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.getAccount(accno);
	}

	@Override
	public boolean deposit(int accno, double amount) {
		// TODO Auto-generated method stub
		return accountDao.deposit(accno, amount);
	}

	@Override
	public boolean withdraw(int accno, double amount) {
		// TODO Auto-generated method stub
		return accountDao.withdraw(accno, amount);
	}

	@Override
	public List<Account> getAccountList() {
		return accountDao.getAccountList();
	}
	
	
    @Override
	public boolean transferFund(int source, int destination, double amount) {
		
		withdraw(source, amount);
              try {
				Thread.sleep(90000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		deposit(destination, amount); 
		
		return true;
	}
	
	
}
