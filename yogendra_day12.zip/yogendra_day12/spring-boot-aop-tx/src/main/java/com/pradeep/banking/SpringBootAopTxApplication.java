package com.pradeep.banking;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.pradeep.banking.model.Account;
import com.pradeep.banking.service.AccountService;

@SpringBootApplication
public class SpringBootAopTxApplication  implements CommandLineRunner {

	
	@Autowired
	private AccountService as;
	
	
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootAopTxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	System.out.println("Inserting the records====");	
	as.addAccount(new Account("Ram", 120000.00, "9156252525", "RAM@gmail.com", "AMXPC9834D", new Date(2011, 11, 11)));
	as.addAccount(new Account("Rahim", 130000.00, "9156252521", "Rahim@gmail.com", "AMXPC9834D", new Date(2011, 11, 11)));
	as.addAccount(new Account("David", 140000.00, "9156252522", "David@gmail.com", "AMXPC9834D", new Date(2011, 11, 11)));
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
