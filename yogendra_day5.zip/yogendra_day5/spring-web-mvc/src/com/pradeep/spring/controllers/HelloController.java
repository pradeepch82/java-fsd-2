package com.pradeep.spring.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller

public class HelloController {

	public HelloController() {
	System.out.println("=============HelloController created==========");
	}
	

	@RequestMapping(value="/hello",method = RequestMethod.GET)
	public String hello() {
		System.out.println("HelloController == hello method  ");
			return "hello";
	}
	
	
	
	@RequestMapping(value="/greet",method = RequestMethod.GET)
	public String greet(ModelMap map) {
		
		map.addAttribute("message", "Hi Yogendra");
		
		System.out.println("HelloController == greet method  ");
			return "greet";
	}
	
	
	@RequestMapping(value="/welcome",method = RequestMethod.GET)
	public String welcome() {
		System.out.println("HelloController == welcome method  ");
			return "welcome";
	}
	
	
	
	

	@RequestMapping(value="/today",method = RequestMethod.GET)
	public @ResponseBody String today() {
		System.out.println("HelloController == today method  ");
			return "Today is :"+new Date();
	}
	
	
	
	
	
}
