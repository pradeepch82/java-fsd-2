import { Directive } from '@angular/core';

@Directive({
  selector: '[appG]'
})
export class GDirective {

  constructor() { }

}
