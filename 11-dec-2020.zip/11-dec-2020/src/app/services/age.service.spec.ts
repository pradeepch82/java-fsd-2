import { TestBed } from '@angular/core/testing';

import { AgeService } from './age.service';

describe('AgeService', () => {
  let service: AgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Test age wiht lower boundry :20', () => {
    expect(service.validateAge(20)).toEqual(true);
  });

  it('Test age with upper boundry :60', () => {
    expect(service.validateAge(60)).toEqual(true);
  });

  it('Test age within  boundry :26', () => {
    expect(service.validateAge(26)).toEqual(true);
  });


  it('Test age with below lower boundry :15', () => {
    expect(service.validateAge(15)).toEqual(false);
  });

 
  it('Test age with above upper boundry :15', () => {
    expect(service.validateAge(67)).toEqual(false);
  });


});
