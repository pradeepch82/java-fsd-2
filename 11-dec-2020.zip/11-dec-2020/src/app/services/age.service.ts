import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgeService {

  constructor() { }

validateAge(age:number):boolean{
  return age>=20 && age<=60;
}

}
