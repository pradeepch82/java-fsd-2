package com.anusha.animal;

class Student {
	int id = 101;
	String name = "Anusha";
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 10;
	}
	
}

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s= new Student();
		Student s1= new Student();
		Student s2= new Student();
		System.out.println("shashcode " + s.hashCode());
		System.out.println("shashcode " + Integer.toHexString(s.hashCode()));
		System.out.println(s.toString());
		System.out.println(s);
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
	}

}
