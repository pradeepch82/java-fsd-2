package com.anusha.animal;

abstract class  Animal {
	public Animal() {
		System.out.println("Animal object created");
	}
	abstract void  makeNoise();

}

class Dog extends Animal {
	public Dog() {
		System.out.println("Dog object created");
	}
	@Override
	void makeNoise() {
		System.out.println("Dog makes noise woof woof");		
	}
	
}

class Cat extends Animal {
	 public Cat() {
		// TODO Auto-generated constructor stub
		 System.out.println("Cat object created");
	}
	@Override
	void makeNoise() {
		System.out.println("Cat makes noise Meow");		
	}
	
}

class Horse extends Animal {
	public Horse() {
		// TODO Auto-generated constructor stub
		System.out.println("Horse object created");
		}
	@Override
	void makeNoise() {
		System.out.println("Horse makes noise burr burr");		
	}
	
}

public class Animals {

	public static void main(String[] args) {
		Animal a = null;
		Dog d= new Dog();
		Cat c= new Cat();
		Horse h= new Horse();
		a=d;
		a.makeNoise();
		a=c;
		a.makeNoise();
		a=h;
		a.makeNoise();
	
	}

}
