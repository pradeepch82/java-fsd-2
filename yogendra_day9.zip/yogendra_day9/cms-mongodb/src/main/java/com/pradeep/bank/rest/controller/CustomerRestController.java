package com.pradeep.bank.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.bank.model.Customer;
import com.pradeep.bank.service.CustomerService;

@RestController
@RequestMapping("/rest/customers")
public class CustomerRestController {

	@Autowired
	private CustomerService cs; // dependency

	public CustomerRestController() {
		System.out.println("====CustomerRestController  created==========");
	}

	@GetMapping
	public List<Customer> getAllCustomers() {
		return cs.findAllCustomers();
	}

	@PutMapping("/{customerId}")
	public List<Customer> updateCustomer(@PathVariable("customerId") int customerId, @RequestBody Customer customer) {

		cs.updateCustomer(customer);

		return cs.findAllCustomers();
	}

	@DeleteMapping("/{customerId}")
	public List<Customer> deleteCustomer(@PathVariable("customerId") int customerId) {

		cs.deleteCustomer(customerId);

		return cs.findAllCustomers();
	}

	@PostMapping
	public List<Customer> addCustomer(@RequestBody Customer customer) {

		cs.saveCustomer(customer);

		return cs.findAllCustomers();
	}

	@GetMapping("/{customerId}")
	public Customer getCustomer(@PathVariable("customerId")int customerId) {

		return cs.findCustomer(customerId);
	}

}
