package com.pradeep.bank.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.pradeep.bank.model.Customer;


@Repository
public interface CustomerDao  extends MongoRepository<Customer, Integer>{
	
	
}
