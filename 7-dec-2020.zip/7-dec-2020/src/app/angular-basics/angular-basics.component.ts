import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {


  title='Angular Basics'; //string

  colors=['red','green','blue','magenta']; //array

  day=1; //number

  min:number=1; //number

  max=8;  //number

  show=true;  //boolean

  hide:boolean=false; //boolean  

 
  time=new Observable<string>((s:Subscriber<string>)=>{
    
    setInterval(()=>{
      s.next(new Date().toLocaleString());
    },1000);
    
  });


 employee={
        id:101,
        name:'Pradeep chinchole',
        salary:45644.42223444,
        variable:0.15,
        doj:new Date(),
        pan:'amxpc9856g',
        mobile:'9158762526',
        
      };  //object


      showHide(){
       this.hide=!this.hide; 
      }


   











  constructor() { 
    console.log("============AngularBAsics component created===============");
  }

  ngOnInit(): void {
    console.log("============AngularBAsics component initialized===============");
    
  }

  ngOnDestroy(): void {
    console.log("============AngularBasics component destroyed===============");
  }


}
