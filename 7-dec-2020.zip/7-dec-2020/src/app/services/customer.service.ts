import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

private baseURL="http://localhost:1111/spring-boot-cms-v1/customers";

  constructor(private http:HttpClient) {
    console.log("========PostsService creaed=========");
   }


   getAllCustomers():Observable<any>{
     return this.http.get(this.baseURL);
   }

   getCustomerById(customerId:number):Observable<any>{
    return this.http.get(this.baseURL+"/"+customerId);
  }

  deleteCustomerById(customerId:number):Observable<any>{
    return this.http.delete(this.baseURL+"/"+customerId);
  }
 
  updateCustomerById(customerId:number,customer :any):Observable<any>{
    return this.http.put(this.baseURL+"/"+customerId,customer);
    }
  
    addCustomer(customer :any):Observable<any>{
      return this.http.post(this.baseURL,customer);
      }
    

}
