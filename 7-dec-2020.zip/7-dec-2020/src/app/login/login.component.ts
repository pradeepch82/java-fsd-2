import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent created   $$$$$$$$$$")
  }

  ngOnInit() {

     console.log("$$$$$$$$$$$$$$$$$$ LoginComponent initialized   $$$$$$$$$$")
  
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ LoginComponent ngAfterViewInit  $$$$$$$$$$")
  }

  ngDoCheck() {
    console.log("############ LoginComponent  ngDoCheck #############");
  }


}
