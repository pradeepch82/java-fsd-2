import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  
  constructor() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent created   $$$$$$$$$$")
   }

  ngOnInit() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent initialized   $$$$$$$$$$")
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ RegisterComponent ngAfterViewInit $$$$$$$$$$")
  }


}
