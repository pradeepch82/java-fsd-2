
Customer
========

customerId (auto genrated)
firstName
lastName
gender
email
address
city
state



CustomerMainApp
         CustomerService
                 CustomerDao
                          CustomerMap







Product
========
productId (auto genrated)
productName
price



ProductMainApp
         ProductService
                 ProductDao
                          ProductMap





Day2
====
        
                          BeanFactory
                              |
                        ApplicationContext
                        
        ClassPathXMLApplicationXContext     AnnotationConfigApplicationContext
                              |
                       WebApplicationContext    



IOC

DI
  setter   -><property name="cs" ref="customerService">
  constructor -><constructor-arg   name="cs" ref="customerService">
                          
                                                    
Spring Bean Life Cycle
==========================
1.Instantation
2.Dependency Injection
3.Initialization
4.Service
5.Destruction


Spring Bean Scope : singletone|prototype



Wiring :Associations of spring beans with each other

Autowiring :It is a mechanism of delagating the responsibilty of
            Associations of spring beans with each other to spring container                       


             auto-wire=no|byName|byType|constructor


Day3
====
                              @Component
                              
                              
  @Controller                 @Service                @Repository
  
  
  
2) @PostConstruct = init-method attribute

3) @PreDestroy = destroy method

4) @Autowire 

5) @Qualifier
  
6) @Configuration

7) @ComponentScan 
  
  
  
  
                                
















