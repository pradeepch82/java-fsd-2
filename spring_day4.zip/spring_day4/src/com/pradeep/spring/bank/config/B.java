package com.pradeep.spring.bank.config;

import org.springframework.stereotype.Component;

@Component
public class B{

	public B() {
		System.out.println("B Class constructor created..");
}
}
