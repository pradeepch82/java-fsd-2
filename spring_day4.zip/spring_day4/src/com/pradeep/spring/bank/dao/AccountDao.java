package com.pradeep.spring.bank.dao;

import java.util.List;

import com.pradeep.spring.bank.model.Account;

public interface AccountDao {

	boolean addAccount(Account account);

	boolean deleteAccount(int accno);

	List<Account> findAllAccounts();

	Account findAccount(int accno);

	boolean saveAccount(Account account);

}
