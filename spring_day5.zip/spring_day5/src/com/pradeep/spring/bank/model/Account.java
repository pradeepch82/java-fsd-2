package com.pradeep.spring.bank.model;

import java.util.Date;
import java.util.Random;

public class Account {

	private int accno;
	private String name;
	private double balance;
	private Date doc;

	public Account() {
		this.accno = new Random().nextInt(100000);
		this.doc = new Date();
	}

	public Account(String name, double balance) {
		this.accno = new Random().nextInt(100000);
		this.doc = new Date();
		this.name = name;
		this.balance = balance;
	}

	public int getAccno() {
		return accno;
	}

	
	public void setAccno(int accno) {
		this.accno = accno;
	}
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getDoc() {
		return doc;
	}

	
	public void setDoc(Date doc) {
		this.doc = doc;
	}
	

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", name=" + name + ", balance=" + balance + ", doc=" + doc + "]";
	}

}
