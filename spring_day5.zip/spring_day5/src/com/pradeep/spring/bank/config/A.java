package com.pradeep.spring.bank.config;

import org.springframework.stereotype.Component;

@Component
public class A {

	public A() {
		System.out.println("A Class constructor created..");
}
}
