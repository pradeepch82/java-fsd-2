package com.pradeep.spring.bank.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//@ComponentScan(basePackages = {"com"})
//@Configuration
public class BankConfig {

	public BankConfig() {
System.out.println("Bank Config object created..");
	}
	
}
