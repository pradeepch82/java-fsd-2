package com.pradeep.spring.bank.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pradeep.spring.bank.model.Account;

//@Component
@Repository

public class MySQLAccountDaoImpl implements AccountDao {

	private JdbcTemplate jdbcTemplate;

	public MySQLAccountDaoImpl() {
		System.out.println("MySQLAccountDaoImpl  created successfully");
	}

	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		System.out.println("In setJdbcTemplate......");
	}

	public MySQLAccountDaoImpl(JdbcTemplate jdbcTemplate) {
		System.out.println("MySQLAccountDaoImpl  param constructor....");
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return jdbcTemplate.update("INSERT INTO ACCOUNTS VALUES(?,?,?,?)", account.getAccno(), account.getName(),
				account.getBalance(), account.getDoc()) == 1;

	}

	@Override
	public boolean deleteAccount(int accno) {
		// TODO Auto-generated method stub
		return jdbcTemplate.update("DELETE FROM ACCOUNTS WHERE ACCNO=?") == 1;
	}

	@Override
	public List<Account> findAllAccounts() {

		return jdbcTemplate.query("SELECT * FROM ACCOUNTS", new AccountRowMapper());
	}

	@Override
	public Account findAccount(int accno) {
		return jdbcTemplate.queryForObject("SELECT * FROM ACCOUNTS WHERE ACCNO=?", new AccountRowMapper(), accno);
	}

	@Override
	public boolean saveAccount(Account account) {
		return jdbcTemplate.update("UPDATE ACCOUNTS SET NAME=?,BALANCE=?,DOC=? WHERE ACCNO=?", account.getName(),
				account.getBalance(), account.getDoc(), account.getAccno()) == 1;
	}

}
