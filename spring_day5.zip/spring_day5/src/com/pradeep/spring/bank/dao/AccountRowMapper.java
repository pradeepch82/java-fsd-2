package com.pradeep.spring.bank.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pradeep.spring.bank.model.Account;

public class AccountRowMapper implements RowMapper<Account> {

	@Override
	public Account mapRow(ResultSet rs, int arg1) throws SQLException {
System.out.println("In map row");
		Account a = new Account();
		a.setAccno(rs.getInt(1));
		a.setName(rs.getString(2));
		a.setBalance(rs.getDouble(3));
		a.setDoc(rs.getDate(4));

		return a;
	}

}
