package com.pradeep.bank.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "p_customers")
public class Customer implements Serializable{

	@Id
	private int customerId;
    private String name;
    private String pan;
    private String mobile;         
    
    @Column(name="dob")
    private Date dateOfBirth;
    private String address;
    
	public Customer() {
	this.customerId=new Random().nextInt(100000);
	}

	public Customer(String name, String pan, String mobile, Date dateOfBirth,
			String address) {
		super();
		this.customerId=new Random().nextInt(100000);
		this.name = name;
		this.pan = pan;
		this.mobile = mobile;
		
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}

	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
	public int getCustomerId() {
		return customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", pan=" + pan + ", mobile=" + mobile
				+ ", dateOfBirth=" + dateOfBirth + ", address=" + address + "]";
	}
    
		
	
}
