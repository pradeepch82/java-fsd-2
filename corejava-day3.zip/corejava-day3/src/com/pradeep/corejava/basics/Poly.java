package com.pradeep.corejava.basics;

public class Poly {

	
	public void sum(int a, int b) {
		System.out.println("Sum of 2 numbers "+(a+b));
	}
	
	public void sum(int a, int b,int c) {
		System.out.println("Sum of 3 numbers "+(a+b+c));
	}
	
	public void sum(float a, float b) {
		System.out.println("Sum of 2 float numbers "+(a+b));
	}
	
	public void show(int id, String name) {
		System.out.println("Id "+id+"  Name "+name);
	}
	
	public void show(String name,int id) {
		System.out.println("  Name "+name+" Id "+id);
	}
	
	
	
	
	
	public static void main(String[] args) {
	
		
		Poly p1=new Poly();
		
		p1.sum(100, 20);
		p1.sum(100, 20,30);
		
		p1.sum(100.66f, 205.66f);
		p1.show(100,"Raja");
		p1.show("Rama",23);
		
		
		
		

	}

}
