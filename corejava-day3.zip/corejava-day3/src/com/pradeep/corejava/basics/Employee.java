package com.pradeep.corejava.basics;

public class Employee {

    //properties  instance variable
	private int employeeId;        //default value 0
	private String employeeName;   //default value null
	private double employeeSalary; //default value 0.0
	private String city;           //default value null 
	
	 public Employee() {
	 System.out.println("Employee default constructor created...");
	 }

	public Employee(int employeeId, String employeeName, double employeeSalary, String city) {
		 System.out.println("Employee param constructor created...");
			
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.city = city;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	 
	 
	public static void main(String[] args) {

		/*
		 * //create object/instance of Employee
		 * 
		 * Employee e1=new Employee(); Employee e2=new
		 * Employee(101,"Ram",4500.55,"Pune"); e2=new
		 * Employee(101,"Ram",4500.55,"Mumbai");
		 * 
		 * 
		 * e1.setEmployeeId(103); e1.setEmployeeName("Sachin");
		 * 
		 * e1.setEmployeeName("SachinNew"); e1.setEmployeeSalary(5678.88);
		 * e1.setCity("Mumbai");
		 * 
		 * 
		 * //Display employee details System.out.println("Employee e1 details");
		 * System.out.println("==============================");
		 * System.out.println("Employee Id     :"+e1.getEmployeeId());
		 * System.out.println("Employee Name   :"+e1.getEmployeeName());
		 * System.out.println("Employee Salary :"+e1.getEmployeeSalary());
		 * System.out.println("Employee City   :"+e1.getCity());
		 * 
		 * 
		 * //Display employee details System.out.println("Employee e2 details");
		 * System.out.println("==============================");
		 * System.out.println("Employee Id     :"+e2.getEmployeeId());
		 * System.out.println("Employee Name   :"+e2.getEmployeeName());
		 * System.out.println("Employee Salary :"+e2.getEmployeeSalary());
		 * System.out.println("Employee City   :"+e2.getCity());
		 * 
		 */		
		
		Manager m=new Manager();
		
		
		m.setEmployeeId(111);
		m.setEmployeeName("raja");
		m.setEmployeeSalary(7777.99);
		m.setCity("Pune");
		
		
		  //Display employee details System.out.println("Employee e1 details");
		  System.out.println("==============================");
		  System.out.println("Employee Id     :"+m.getEmployeeId());
		  System.out.println("Employee Name   :"+m.getEmployeeName());
		  System.out.println("Employee Salary :"+m.getEmployeeSalary());
		  System.out.println("Employee City   :"+m.getCity());
		  
		
		
	}
	
	
}


class Manager extends Employee{
}
class Programmer extends Employee{
}
class Accountant extends Employee{
}















