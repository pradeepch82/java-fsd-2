package com.pradeep.corejava.basics;

public class Student {
int id=888;
String name="Pradeep Chinchole";

public static void main(String[] args) {
	
	Student s=new Student();
   

	
	
	
}
	
}
