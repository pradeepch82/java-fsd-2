jdbc -Java Database connectivity

Database   (RDBMS)  Ex. Oracle,MySQL,Db2,SQL Server
====================
employee
=====================================================
id         name          salary         doj
======================================================
101       Pradeep        12000          12-May-2020
102       Sachin         12000          12-May-2020
103       Mahesh         12000          12-May-2020
104       Mahesh         12000          12-May-2020
      




drop database company;
create database company;
use company;
create table employee(id int primary key,name text,salary double,doj date);
insert into employee values(101,'Ram',12000.455,'2011-11-11');
insert into employee values(102,'Sachin',13000.455,'2012-11-10');
insert into employee values(103,'Mohan',14000.455,'2013-11-12');
insert into employee values(104,'Mahesh',15000.455,'2014-11-15');
select * from employee;

















API (Application Program interface)
 
java.sql
=========
Driver              (I)
DriverManager       (C) 
Connection          (I)
Statement           (I)
PreparedStatement   (I)
CallableStatement   (I)   :is used to execute Stored Procedure and Functions from database
ResultSet           (I) 
Types               (C)
Date                (C)



Statement
   |
PreparedStatment
   |
CallableStatement


Statement st=con.createStatement();
   
st.executeUpdate("insert into account values(101,'Ameya',12000.455,'2011-11-16')");
			
	1.Parse the query
	2.Compile the query
	3.Prepare for data areas
	4.execute the query		
			      



PreparedStatement ps=con.prepareStatement("insert into account values(?,?,?,?)");


               if(ps.executeUpdate()==1)
               System.out.println("Account inserted successfully");
               else
               System.out.println("Problem in inserting the account");
               






 



