package com.pradeep.corejava.basics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/*
 *  A group of statements executed as a single unit is called transaction.
 * 
 * 
 * 
 * */
public class Transaction {

	public static void main(String[] args) {

		Connection con = null;
		Statement st = null;

		try {

			// register the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver loaded....");

			// establish the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/company", "root", "admin");
			System.out.println("Connection established with MySQL");

			System.out.println("Transaction started.....");

			
			con.setAutoCommit(false);
			st = con.createStatement();

			st.executeUpdate("update account set balance=balance-100 where accno=101");
			System.out.println("Source account debited....");

			 //int a=100/0;
			
			st.executeUpdate("update account set balance=balance+100 where accno=102");
			System.out.println("Destination account credited....");

			con.commit();
			
			System.out.println("Transaction completed....");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			
			try {
				con.rollback();
				System.out.println("Transaction aborted....");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			
		} finally {
			if (con != null)
				try {
					con.close();
					System.out.println("Connection is closed.....");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
