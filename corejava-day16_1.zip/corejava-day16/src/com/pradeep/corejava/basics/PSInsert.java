package com.pradeep.corejava.basics;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class PSInsert {

	public static void main(String[] args) {

		Connection con = null;
		PreparedStatement ps=null;

		try {

			// register the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver loaded....");

		   // establish the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/company", "root", "admin");
			System.out.println("Connection established with MySQL");
			
			ps=con.prepareStatement("insert into account values(?,?,?,?)");
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter accno :");
			ps.setInt(1, sc.nextInt());
			System.out.println("Enter name :");
			ps.setString(2, sc.next());
			System.out.println("Enter balance :");
			ps.setDouble(3, sc.nextDouble());
			System.out.println("Enter doc (yyyy-mm-dd) :");
			ps.setDate(4,Date.valueOf(sc.next()));
			

            if(ps.executeUpdate()==1)
            System.out.println("Account inserted successfully");
            else
            System.out.println("Problem in inserting the account");
			
			

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
					System.out.println("Connection is closed.....");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
