package com.pradeep.corejava.basics;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class PSUpdate {

	public static void main(String[] args) {

		Connection con = null;
		PreparedStatement ps=null;

		try {

			// register the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver loaded....");

		   // establish the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/company", "root", "admin");
			System.out.println("Connection established with MySQL");
			
			ps=con.prepareStatement("update account set balance=balance+? where accno=?");
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter accno :");
		    int accno=sc.nextInt();
		    System.out.println("Enter amount :");
		    double amount=sc.nextDouble();
		    		    
			ps.setDouble(1, amount);
			ps.setInt(2, accno);
		    
		    

            if(ps.executeUpdate()==1)
            System.out.println("Account  ["+accno+"] is credited by "+amount+" successfully");
            else
            System.out.println("Account ["+accno+"] does not exist");
			
			

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
					System.out.println("Connection is closed.....");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
