package com.pradeep.spring.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pradeep.spring.bank.model.Account;
import com.pradeep.spring.bank.service.AccountService;

//@Component
@Controller
public class BankController {

	private AccountService as;

	public BankController() {

		System.out.println("=========MainApp created============");
	}

	public AccountService getAs() {
		return as;
	}

	
	public void setAs(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp setAs method....============");

	}

	@Autowired
	public BankController(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp param constructor....============");

	}

			
	@RequestMapping(value="/accounts",method = RequestMethod.GET)
	public @ResponseBody  List<Account> findAllAccounts() {
		return as.findAllAccounts(); 
	}
	
	@RequestMapping(value="/accounts/{accno}",method = RequestMethod.GET)
	public @ResponseBody Account findAccount(@PathVariable("accno") int accno) {
		return as.findAccount(accno); 
	}
	
	@RequestMapping(value="/accounts/{accno}",method = RequestMethod.DELETE)
	public @ResponseBody List<Account> deleteAccount(@PathVariable("accno") int accno) {
		as.deleteAccount(accno);
		return as.findAllAccounts(); 
	}
	
	@RequestMapping(value="/accounts/{accno}",method = RequestMethod.PUT)
	public @ResponseBody List<Account> updateAccount(@PathVariable("accno") int accno, @RequestBody Account account) {
		as.saveAccount(account);
		return as.findAllAccounts(); 
	}
	
	
	@RequestMapping(value="/accounts",method = RequestMethod.POST)
	public @ResponseBody List<Account> addAccount(@RequestBody Account account) {
		as.addAccount(account);
		return as.findAllAccounts(); 
	}
	
	public void myinit() {
		System.out.println("Main App Init Method..");
	}
	
	public void mydestroy() {
		System.out.println("Main App Destroy Method..");
	}
	
	
}
