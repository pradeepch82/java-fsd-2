package com.pradeep.corejava.basics;

import java.util.Arrays;

public class StringDemo {

	public static void main(String[] args) {
		
		//create string
		String s1="This is a Java. ";
		String s2=new String("I like it");
		char arr[]= {'S','A','I',' ','T','E','C','H'};
		String s3=new String(arr);
		byte arr1[]= {65,66,67,68,69}; // 65 66 67 68 69
		String s4=new String(arr1);
		
		String s5=" Hello ";
		
		System.out.println("s1  :"+s1);
		System.out.println("s2  :"+s2);
		System.out.println("s3  :"+s3);
		System.out.println("s4  :"+s4);
		
		System.out.println("Length of s1 :"+s1.length());
		System.out.println("s1.concat(s2)  :"+s1.concat(s2));
		System.out.println(s1+" at "+s3);
		System.out.println("s1.indexOf('a')      :"+s1.indexOf('a'));
		System.out.println("s1.lastIndexOf('a')  :"+s1.lastIndexOf('a'));
		
		String p=s2.substring(0, 7);
		String q=s3.substring(0);
		System.out.println(p+q);
		
		System.out.println("s1 in lowercase :"+s1.toLowerCase());
		System.out.println("s1 in uppercase :"+s1.toUpperCase());
		System.out.println("s1.chart(8)   :"+s1.charAt(8));
		
		
		System.out.println("Before trim :"+s5.length());
		s5=s5.trim();
		System.out.println("After  trim :"+s5.length());
		
		System.out.println("Is s1.starts  with This  :"+s1.startsWith("This"));
		System.out.println("Is s1. end with This     :"+s1.endsWith("This"));
		
		System.out.println("s1==s2        :"+(s1==s2));
		System.out.println("s1.equals(s2) :"+s1.equals(s2));
		
		System.out.println("Byte Array :"+Arrays.toString(s4.toCharArray()));
		System.out.println("Byte Array :"+Arrays.toString(s4.getBytes()));
		
		
		
		

	}

}
