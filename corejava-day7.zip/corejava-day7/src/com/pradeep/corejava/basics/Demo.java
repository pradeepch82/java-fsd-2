package com.pradeep.corejava.basics;

public class Demo {
public static void main(String[] args) {
	
	String s=new String("Hello World");
	
	StringBuffer sb=new StringBuffer("Hello World");
	
	System.out.println("Before :");
	System.out.println("string         :"+s);
	System.out.println("stringbuffer   :"+sb);
	
	String f=s.toLowerCase();
	
	sb.append("Good Bye");
	
	System.out.println("After  :");
	System.out.println("string         :"+s);
	System.out.println("stringbuffer   :"+sb);
	System.out.println(" d             :"+f);
	
	
	
	
	
}
}
