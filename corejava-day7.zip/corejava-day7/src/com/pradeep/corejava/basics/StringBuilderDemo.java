package com.pradeep.corejava.basics;

public class StringBuilderDemo {

	public static void main(String[] args) {

		String first="Pradeep ";
		String mid="Vasant ";
		String last="Chinchole ";
		
		StringBuilder sb=new StringBuilder(5); //default capapcity 16
		//StringBuffer sb=new StringBuffer(5); //default capapcity 16
		
		
		System.out.println("Intital Capacity :"+sb.capacity());
		System.out.println("Contents         :"+sb);
		sb.append(first);
		System.out.println("====================");
		System.out.println("Intital Capacity :"+sb.capacity());
		System.out.println("Contents         :"+sb);
		sb.append(last);
		System.out.println("====================");
		System.out.println("Intital Capacity :"+sb.capacity());
		System.out.println("Contents         :"+sb);
        sb.insert(first.length(),mid);
        System.out.println("Intital Capacity :"+sb.capacity());
		System.out.println("Contents         :"+sb);
        System.out.println("Reverse Name :"+sb.reverse());
		
		
		
		
		

	}

}
