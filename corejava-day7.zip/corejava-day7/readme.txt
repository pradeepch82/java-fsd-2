java.lang  : default package  
           : You need not import this package
           :It is available for all the programs    

Wrapper claases
================
Byte
Short
Integer
Long
Float
Double
Character
Boolean


String
StringBuffer
StringBuilder : Java 5


What is the difference between String and String Buffer and StringBuilder ?
==============================================================================
String Buffer     : is Thread Safe     : At a time we can perform only one operation on stringbuffer object
String Builder    : is Non Thread Safe : At a time we can perform more than one operation on stringbuilder object

String : String class objects are immutable
         Contents can not be changed
         All wrapper class objects are immutable   

StringBuffer/StringBuider : StringBuffer/StringBuilder class objects are mutable
        Contents can be changed

