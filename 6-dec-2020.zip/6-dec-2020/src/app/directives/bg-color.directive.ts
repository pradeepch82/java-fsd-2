import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  constructor(private el:ElementRef,private r:Renderer2) {
    console.log("============BgColorDirective created===========");
   }
   @Input()
  set bgColor(value){
    console.log("In setBgColor  :"+value);
    this.r.setStyle(this.el.nativeElement,"background-color",value);
  }

}

