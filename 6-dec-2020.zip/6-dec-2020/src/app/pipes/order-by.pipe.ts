import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(array: any[], field?:string,descending?:boolean):any[] {
    
    
    var fieldType =typeof(array[0][field]);
    console.log("Field Type :"+fieldType);


    if(fieldType=='number')
    array.sort((a,b)=>a[field]-b[field]);
    else if(fieldType=='string')
    array.sort((a,b)=>a[field].localeCompare(b[field]));
    if(fieldType=='object')
    array.sort((a,b)=>a[field].getTime()-b[field].getTime());
         



    if(descending)
    array.reverse();
    
    return array;
  }

}
