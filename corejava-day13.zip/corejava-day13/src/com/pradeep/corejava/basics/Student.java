package com.pradeep.corejava.basics;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Student implements Comparable<Student>,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private Double marks;
	private int age;
	private String email;
	private Date dob;
	
	private static final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	
	
	
	public Student() {
		
		
	}
	
	
	public Student(int id, String name, double marks, int age, String email, String dob) throws ParseException {
		this.id = id;
		this.name = name;
		this.marks = marks;
		this.age = age;
		this.email = email;
		this.dob = sdf.parse(dob);
	}





	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", marks=" + marks + ", age=" + age + ", email=" + email
				+ ", dob=" + dob + "]";
	}
	
	
	
	@Override
	public int compareTo(Student o) {
		return id-o.getId();//id basis
	}
		
	
}
