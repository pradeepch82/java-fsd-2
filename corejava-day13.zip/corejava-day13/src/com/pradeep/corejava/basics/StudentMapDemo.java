package com.pradeep.corejava.basics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class StudentMapDemo {

	Map<Integer, Student> map;

	public StudentMapDemo() throws IOException, ClassNotFoundException {

		File f = new File("mapdata");

		if (f.exists()) {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			map = (Map<Integer, Student>) ois.readObject();

			System.out.println("Existing  map received.... map size :" + map.size());

		} else {
			map = new HashMap<>();
			System.out.println("New map created..... map size :" + map.size());
		}

	}

	void addStudent(Student student) {

		map.put(student.getId(), student);
		System.out.println("Student added.....");

	}

	void updateStudent(Student student) {

		if (map.containsKey(student.getId())) {
			map.put(student.getId(), student);
			System.out.println("Student updated.....");
		} else
			System.out.println("Student doesn't exist");

	}

	void deleteStudent(int studentId) {
		if (map.containsKey(studentId)) {
			map.remove(studentId);
			System.out.println("Student removed.....");
		} else
			System.out.println("Student doesn't exist");
	}

	void showStudent(int studentId) {
		if (map.containsKey(studentId)) {

			System.out.println("Student Details\n=========..");
			System.out.println(map.get(studentId));
		} else
			System.out.println("Student doesn't exist");

	}

	void showAllStudents() {

		System.out.println("=========================================");
		System.out.println("All Students");
		System.out.println("=========================================");
		for (Student s : map.values())
			System.out.println(s);

	}

	void showAllStudentsSortedByStudentId() {

		TreeMap<Integer, Student> tm = new TreeMap<>(map);

		System.out.println("=========================================");
		System.out.println("All Students Sorted by Student Id");
		System.out.println("=========================================");
		for (Student s : tm.values())
			System.out.println(s);

	}

	void showAllStudentsSortedByStudentName() {

		ArrayList<Student> list = new ArrayList<>(map.values());

		Collections.sort(list, (a, b) -> a.getName().compareTo(b.getName()));

		
		System.out.println("==================================");
		System.out.println("Students sorted by Student Name");
		System.out.println("==================================");

		for (Student s : list)
			System.out.println(s);
	}

	void showAllStudentsSortedByStudentMarks() {

		ArrayList<Student> list = new ArrayList<>(map.values());

		Collections.sort(list, (a, b) -> a.getMarks().compareTo(b.getMarks()));

		System.out.println("==================================");
		System.out.println("Students sorted by Student Marks");
		System.out.println("==================================");

		for (Student s : list)
			System.out.println(s);

	}

	void showAllStudentsSortedByStudentAge() {

		ArrayList<Student> list = new ArrayList<>(map.values());

		Collections.sort(list, (a, b) -> a.getAge() - b.getAge());
		
		
		System.out.println("==================================");
		System.out.println("Students sorted by Student Age");
		System.out.println("==================================");

		for (Student s : list)
			System.out.println(s);

	}

	void showAllStudentsSortedByStudentEmail() {

		ArrayList<Student> list = new ArrayList<>(map.values());

		Collections.sort(list, (a, b) -> a.getEmail().compareTo(b.getEmail()));

		
		System.out.println("==================================");
		System.out.println("Students sorted by Student Email");
		System.out.println("==================================");

		for (Student s : list)
			System.out.println(s);
	}

	void showAllStudentsSortedByStudentDob() {

		ArrayList<Student> list = new ArrayList<>(map.values());

		Collections.sort(list, (a, b) -> a.getDob().compareTo(b.getDob()));

		System.out.println("==================================");
		System.out.println("Students sorted by Student Dob");
		System.out.println("==================================");

		for (Student s : list)
			System.out.println(s);
		
	}

	void showNumberOfStudents() {
		System.out.println("Number of Students :" + map.size());

	}

	void saveData() throws IOException {

		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("mapdata"));

		oos.writeObject(map);

		System.out.println("Students stored inside the file.....");

	}

	public static void main(String[] args) throws ParseException, ClassNotFoundException, IOException {

		// To read the data from key board

		int choice = 0;
		Scanner sc = new Scanner(System.in);
		StudentMapDemo sd = new StudentMapDemo();

		while (choice < 14) {
			System.out.println("Student Operations");
			System.out.println("========================");
			System.out.println("1.Add Student");
			System.out.println("2.Get Student");
			System.out.println("3.Delete Student");
			System.out.println("4.Update Student");
			System.out.println("5.Show All Students");
			System.out.println("6.Show Number of Students");
			System.out.println("7.Show Students Sorted by Student Id");
			System.out.println("8.Show Students Sorted by Student NAme");
			System.out.println("9.Show Students Sorted by Student MArks");
			System.out.println("10.Show Students Sorted by Student Age");
			System.out.println("11.Show Students Sorted by Student Email");
			System.out.println("12.Show Students Sorted by Student DOB");
			System.out.println("13.Exit");

			System.out.println("===========================");
			System.out.println("Enter the Choice   :");

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Student Id,Name,Marks,age,email and dob (dd-MM-yyyy)");

				Student student = new Student(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.next(),
						sc.next());

				sd.addStudent(student);
				break;

			case 2:
				System.out.println("Enter Student Id :");

				sd.showStudent(sc.nextInt());

				break;

			case 3:
				System.out.println("Enter Student Id :");

				sd.deleteStudent(sc.nextInt());

				break;

			case 4:
				System.out.println("Enter Student Id,Name,Marks,age,email and dob (dd-MM-yyyy)");

				student = new Student(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.next(), sc.next());

				sd.updateStudent(student);
				break;

			case 5:

				sd.showAllStudents();
				break;
			case 6:

				sd.showNumberOfStudents();
				break;
			case 7:

				sd.showAllStudentsSortedByStudentId();
				break;
			case 8:

				sd.showAllStudentsSortedByStudentName();

				break;
			case 9:

				sd.showAllStudentsSortedByStudentMarks();
				break;
			case 10:

				sd.showAllStudentsSortedByStudentAge();
				break;
			case 11:

				sd.showAllStudentsSortedByStudentEmail();
				break;
			case 12:

				sd.showAllStudentsSortedByStudentDob();
				break;

			default:
				sd.saveData();
				return;
			}// switch

		} // while

	}// main

}// class
