package com.pradeep.corejava.basics;

class Student{
	int id=101;
	String name="Pradeep";
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
	@Override
	public boolean equals(Object obj) {
	    Student s=(Student)obj;
	    		
		return id==s.id && name.equals(s.name);
	}
	
	
	
	
	
}

public class ToStringDemo {
public static void main(String[] args) {
	
	Integer i=new Integer(34);
	Integer j=new Integer(34);
	
	
	Student s1=new Student();
	Student s2=new Student();
	
	
	System.out.println(i.hashCode()+"    "+j.hashCode());
	System.out.println(s1.hashCode()+"   "+s2.hashCode());
	
	System.out.println(System.identityHashCode(i));
	System.out.println(System.identityHashCode(j));
	System.out.println(System.identityHashCode(s1));
	System.out.println(System.identityHashCode(s2));
	
	
		/*
		 * System.out.println(s1+"   "+s2); //System.out.println(s.toString());
		 * System.out.println("================"); System.out.println(i+"  "+j);
		 * //System.out.println(i.toString());
		 * 
		 * // == It always compares addresses
		 * 
		 * System.out.println("i==j     :"+(i==j));
		 * System.out.println("s1==2    :"+(s1==s2));
		 * 
		 * // equals System.out.println("i.equals(j)     :  "+i.equals(j));
		 * System.out.println("s1.equals(s2)   :  "+s1.equals(s2));
		 * 
		 */	
}
}
