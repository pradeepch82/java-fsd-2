package com.pradeep.corejava.basics;

public class WrapperClassDemo {
public static void main(String[] args) {
	
	
	//primitive data types
	int i=100;
	byte b=20;
	char c='A';
	float f=45.678f;
	
	
	//Before Java 5
	//Boxing  => Primitive to Object
	Integer ii=new Integer(i);
	Byte bb=new Byte(b);
	Character cc=new Character(c);
	Float ff=new Float(f);
	
	
	//UnBoxing   => Object into primitive
	int iii=ii.intValue();
	byte bbb=bb.byteValue();
	char ccc=cc.charValue();
	float fff=ff.floatValue();
	
	System.out.println(i+"  "+b+"   "+c+"   "+f);
	System.out.println(ii+"  "+bb+"  "+cc+"   "+ff);
	System.out.println(iii+"  "+bbb+"  "+ccc+"   "+fff);
	
	//From Java5  AutoBoxing
	Integer iiii=56;
    Float ffff=67.88f;
	
    //Auto Unboxing
	int x=iiii;
	float y=ffff;
	
	
	
	
	
	
	
	
}
}
