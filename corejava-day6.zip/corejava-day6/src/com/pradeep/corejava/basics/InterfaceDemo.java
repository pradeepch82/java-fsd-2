package com.pradeep.corejava.basics;

import java.util.Arrays;
import java.util.Random;

abstract class Vehicle{
	abstract void drive();
}

interface Flyable{
	void fly();//public abstract
}


class Bus extends Vehicle{
	
	@Override
	void drive() {
	System.out.println("Driver Bus....");	
	}
	
}


class Truck extends Vehicle{
	
	@Override
	void drive() {
	System.out.println("Drive Truck....");	
	}
	
}


class Aeroplane extends Vehicle implements Flyable{
	
	@Override
	void drive() {
	System.out.println("Drive Aeroplane....");	
	}
	
	@Override
	public void fly() {
	System.out.println("Fly Aeroplane....");
	
	}
	
}


class Helicapter extends Vehicle implements Flyable {
	
	@Override
	void drive() {
	System.out.println("Drive Helicapter....");	
	}
	
	@Override
	public void fly() {
	System.out.println("Fly Helicapter....");
	
	}
	
}




public class InterfaceDemo {
public static void main(String[] args) {
	
	//create array of Vehicles with size 5
	Vehicle []vehicles=new Vehicle[5];
	
	System.out.println("Contnets :"+Arrays.toString(vehicles));
	
	Random r=new Random();
	
	
	
	
	
	
	
	for(int i=0;i<vehicles.length;i++) {
		int x=r.nextInt(4);
		System.out.println("x="+x);
		if(x==0)
			vehicles[i]=new Bus();
		else if(x==1)
			vehicles[i]=new Truck();
		else if(x==2)
			vehicles[i]=new Aeroplane();
		else if (x==3)
			vehicles[i]=new Helicapter();
		
		  vehicles[i].drive();
				
	      if(vehicles[i] instanceof Flyable) {
	    	  Flyable f=(Flyable)vehicles[i];
	    	  f.fly();
	      }
	
				
	}
	
	System.out.println("Contnets :"+Arrays.toString(vehicles));
	
	
	
	
}
}
