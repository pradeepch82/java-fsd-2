package com.pradeep.corejava.basics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {

	public static void main(String[] args) {

		Connection con = null;

		try {

			// register the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver loaded....");

		   // establish the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/company", "root", "admin");
			System.out.println("Connection established with MySQL");

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
					System.out.println("Connection is closed.....");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
