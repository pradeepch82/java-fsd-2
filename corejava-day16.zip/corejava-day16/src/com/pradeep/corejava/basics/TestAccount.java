package com.pradeep.corejava.basics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestAccount {

	public static void main(String[] args) {

		Connection con = null;

		try {

			// register the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("MySQL Driver loaded....");

			// establish the connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/company", "root", "admin");
			System.out.println("Connection established with MySQL");

			// create a statement object

			Statement st = con.createStatement();
			System.out.println("Statement object created....");

			/*
			 * boolean execute(String sql) : DDL create,drop,alter int executeUpdate(String
			 * sql) : DML insert,update delete ResultSet executeQuery(String sql) : DRL
			 * select *
			 * 
			 * 
			 */

			// drop a table account

			st.execute("drop table account");
			System.out.println("Table droped.....");

			// create a table account

			st.execute("create table account(accno int primary key,name text,balance double,doc date)");
			System.out.println("Table created.....");

			// insert 4 record....

			st.executeUpdate("insert into account values(101,'Ameya',12000.455,'2011-11-16')");
			st.executeUpdate("insert into account values(102,'Mohan',13000.455,'2012-11-13')");
			st.executeUpdate("insert into account values(103,'Sunil',14000.455,'2013-11-12')");
			st.executeUpdate("insert into account values(104,'Sachin',15000.455,'2015-11-15')");

			System.out.println("4 records inserted.....");

			// retrieve the records

			ResultSet rs = st.executeQuery("select * from account");

			System.out.println("All Accounts");
			System.out.println("=====================================");
			while (rs.next())
				System.out.println(rs.getInt(1) + "     " + rs.getString(2) + "     " + rs.getDouble(3) + "    "
						+ rs.getDate("doc"));

			st.executeUpdate("update account set balance=balance-2000 where accno=101");
			st.executeUpdate("delete from account where accno=104");

			// retrieve the records

			rs = st.executeQuery("select * from account");

			System.out.println("After updation All Accounts");
			System.out.println("=====================================");
			while (rs.next())
				System.out.println(rs.getInt(1) + "     " + rs.getString(2) + "     " + rs.getDouble(3) + "    "
						+ rs.getDate("doc"));
			
			

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
					System.out.println("Connection is closed.....");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
