package com.pradeep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCmsRepoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCmsRepoAppApplication.class, args);
	}

}
