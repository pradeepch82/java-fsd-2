package com.pradeep.spring.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.spring.bank.model.Account;
import com.pradeep.spring.bank.service.AccountService;

@RequestMapping("/rest")
@RestController
public class BankRestController {

	
	@Qualifier("accountMySQLServiceImpl")
	@Autowired
	private AccountService as;

	public BankRestController() {

		System.out.println("=========MainApp created============");
	}

	public AccountService getAs() {
		return as;
	}

	/*
	 * public void setAs(AccountService as) { this.as = as;
	 * 
	 * System.out.println("=========MainApp setAs method....============");
	 * 
	 * }
	 * 
	 * public BankRestController(AccountService as) { this.as = as;
	 * 
	 * System.out.println("=========MainApp param constructor....============");
	 * 
	 * }
	 */
	@PostMapping("/accounts")
	public List<Account> addAccount(@RequestBody Account account) {

		as.addAccount(account);

		return as.findAllAccounts();

	}

	@PutMapping("/accounts/{accno}")
	public List<Account> updateAccount(@PathVariable("accno") int accno, @RequestBody Account account) {

		as.saveAccount(account);

		return as.findAllAccounts();

	}

	@DeleteMapping("/accounts/{accno}")
	public List<Account> deleteAccount(@PathVariable("accno") int accno) {

		as.deleteAccount(accno);

		return as.findAllAccounts();

	}

	@GetMapping("/accounts/{accno}")
	public Account getAccount(@PathVariable("accno") int accno) {

		return as.findAccount(accno);

	}

	@GetMapping("/accounts")
	public List<Account> getAllAccounts() {

		return as.findAllAccounts();

	}

}
