package com.pradeep.corejava.basics;

public class Person {

//properties
private String name="Pradeep Chinchole";
private int age=38;
private double height=5.4;
private boolean isEmployed=true;


public Person() {
System.out.println("Person default constructor...");
}


public Person(String name, int age, double height, boolean isEmployed) {
	this.name = name;
	this.age = age;
	this.height = height;
	this.isEmployed = isEmployed;
}






//behaviour
public void talk(){
	System.out.println("Hello I am "+name);
	System.out.println("My Age  is "+age);
	System.out.println("My Height  is "+height);
	System.out.println("Am I employed "+isEmployed);
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public double getHeight() {
	return height;
}

public void setHeight(double height) {
	this.height = height;
}

public boolean isEmployed() {
	return isEmployed;
}

public void setEmployed(boolean isEmployed) {
	this.isEmployed = isEmployed;
}



}
