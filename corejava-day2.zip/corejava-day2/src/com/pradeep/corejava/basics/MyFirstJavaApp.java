package com.pradeep.corejava.basics;

public class MyFirstJavaApp {

	public static void main(String[] args) {
	
		//create object of Person class
		Person p1=new Person();
		Person p2=new Person("Rajesh",34,5.6,true);
		
		
		p1.setName("Ram");
		p1.setAge(34);
		p1.setEmployed(true);
		p1.setHeight(5.8);
		
	//	p2.setName("Sachin");
	//	p2.setAge(34);
	//	p2.setEmployed(false);
	//	p2.setHeight(5.2);
		
		p1.talk();
		System.out.println("=======================");
		p2.talk();
			
		
	}
	
}
