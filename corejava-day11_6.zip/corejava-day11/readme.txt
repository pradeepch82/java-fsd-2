/*

what is a bug ?
----------------------

	The error commited in a program  is called bug.

	Removing error is called as debugging.

	There are three types of errors

	1.Compile time errors
	-----------------------------
				These errors represent inprpoer use of syntax 
				or grammer language.

				These errors are detected by compiler

class Err
{
public static void main(String s[])
{
System.out.println("Hello")
}
}

2.Runtime errors
-----------------------
			These are the errors occurs due to illegal	operations.
			These errors are detected by JVM

class Err
{
public static void main()
{
System.out.pritln("Hello");
}
}

Most of run time errors are called exceptions

Removing runtime errors is difficult.

3. Logical errors
-----------------------
		These errors are commited in a logic of the program.
		
		Logical errors are not detected by compiler or JVM.
		
        Programmer is responsible for logical errors.
		
class Err
{
public static void main(String s[])
{
float sal=5000f;

sal=sal*10/100;

System.out.println("Salary="+sal);
}
}

By compairing o/p with maually calculated 
results you can detect/suspect  logical errors

Exception
----------------
			An  Exception is rutime error.

What are checked and uchecked exceptions?
----------------------------------------------------
The exceptions which are caught 
by java compiler are called as checked 
excption 

The exceptions which are caught by JVM
are called as unchecked excption 


What is the difference between error and
Exception ?
------------------------------------------------------------------
An exception is an error which is
handled by prorammer

The errors cannot be handled 
by programmer

Every exception is represented as
class in java
 
									java.lang
									       |
                                    Throwable
                                            |              
			 -----------------------------------------------
			 |                                                               |
        Error		                                              Exception
            |                                                                |
--------------------                                    ---------------------
|    |    |   |      |      |                                     |       |    |    |      |    |
All error classes                                 All Exception classes



Exception is a super class for all 
exception subclassees

Error is a super class for all 
error subclasses  

Any  abnormal event in the program is called
an exception



Exception  handeling
----------------------------

When there is an exeception in java the program
will be terminated in the middle,so already opened files
or databases might not be closed,leading to destruction
of data on the system.

							In case of an Exception
	programmer has to perform the follwowig tasks.
	
	1.Display exception details

	2.Display message to the user

	3.Close the files in databases

	Performig the above task is nothing but Exception 
	handeling.

	Exception handeling is done by try,catch,& finally block


syntax:-
----------			
				try
				{
				statements;
				}
				catch(Exception obj)
				{
				statements;
				}
				finally
				{
				statements;
				}


1.  try block contains the statements which are examined      for any exception

2.When there is an exception JVM stores exception details in    stack  and jumps into catch block.

		In catch block we should display exception details 
		to the user & also any general message.

3.finally block contains the statements that executes even
  though there is exception or not.

try-catch-finally
try-catch
try-finally


Checked Exception  :Detected by Java Compiler ,u must hanlde or propogate

ClassNotFoundExcpetion
InstantiationException
IllegalAccessException
FileNotFoundException
InterruptedException
IOException


Uncheked Exception :Detcted by JVM and no need to handle

   RuntimeException

1.ArithmeticException
2.ArrayIndexOutOfBoundsException
3.StringIndexOutOfBoundsException
4.NullPointerException




2.User defined Exception
----------------------------------
These Exceptions are created by user


1.Write a class that extends Exception class

2.write default costructor in the class

3.write a parameterised constructor with string as a    parameter

4.create an object to your class and throw it out using
  throw clause when required

Collection Framework  (Group of classes and interface)  :java.util
=======================================================

Arrays.toString()
Random

Group of elements stored ate some place.
    
Group of students

1.Get all Students
2.Get Student By Id
3.Get Student By Class NAme
4.Sort students by Name
5.Sort students by Age
6.Delete students by Id
7.Update students by Id
8.Get Number of Students
9.Add Student


Array :Collection of elements of similar type
===== 

Static in nature


Sorting
==========
java.lang.Comparable<T>
java.util.Comparator<T>




Write a Application to perform below Operations on Student(id,name,marks,age,email,dob)


1.Add Student
2.Get Student
3.Delete Student
3.Update Student
4.Get all Students
5.Get the number of Student
6.Sort the students by Id
7.Sort the students by name
8.Sort the students by marks
9.Sort the students by age
10.Sort the students by email
11.Sort the students by dob
12.Exit








Write a Application to perform below Operations on Employee(id,name,salary,age,email,dob)


3456 SUNIL 45.55 34 s@gmail.com 11-11-2020
4456 AMEYA 11.55 34 s@gmail.com 11-11-2030
8456 RAMESH 25.55 34 s@gmail.com 11-11-2010
2456 BHIMA  75.55 34 s@gmail.com 11-11-2220
1456 PRAVIN 25.55 34 s@gmail.com 11-11-2017
6256 MOHAN 55.55 34 s@gmail.com 11-11-2019






1.Write Program to accept the sentence from user and show the number of words
  in the sentence (use sc.nextLine() instead of sc.next)
  
  WordCount.java
  
2.Write Program to accept the two sentences from user and show the common words from the 
   two sentences
   (use sc.nextLine() instead of sc.next)
   
   s1= Hello Pramod How are you
   s2= Hello Sachin How are you
   
   Output :[Hello,How,are you] 
   
   CommonWord.java
   
   
3.Write Program to accept the one sentence from user and show word and occurences of the word in the sentence
  (use sc.nextLine() instead of sc.next)
  
  
  
  
   
   Ex. :  s1= Hello Pramod How are you,Good bye Pramod
   
           Hello =1
           How =1
           are=1
           you=1 
           Good=1
           bye=1
           Pramod=2  
  
  WordOccurance.java
  
  
   
Java 5 Features
================
1.java.util.Scanner
2.java.lang.StringBuilder
3.Generics 
4.AutoBoxing/Unboxing
5.Enhanced Foreach loop
6.static imports
7.var args
8.enums
9.annotations


Java 7 Features
================
1.Type inference  :<>
2.AutoCloseable
3.Try with resources
4.Multi catch Exception (|)


Java 8 features
================
1.Functional Interfaces
      The interface which contains only 1 abstract method is know as Function interface

      java.util.function.Function
      
      			 public abstract R apply(T);
         
      java.util.functional.Perdicate
      
       public abstract boolean test(T);
       
       
      java.util.functional.Consumer
      
       public abstract void accept(T);
      
      
      java.util.functional.Supplier
      
       public abstract T get();
      
      java.lang.Comparable
      
          public abstract int compareTo(T);
      
      java.util.Comarator
      
        public abstract int compare(T, T);
        
      
        
       

2.Lambda Expression




Nested Class/Inner Class
========================
1.Nested Inner Class
2.Nested Static Inner Class
3.Nested Method Level Class
4.Anonymus Inner class










































