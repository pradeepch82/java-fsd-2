package com.pradeep.corejava.java8;

import java.util.function.Consumer;
import java.util.function.Predicate;







public class ConsumerDemo {

	
	public static void main(String[] args) {
		
		Consumer<String> c1=(String s)->{System.out.println("HEllo "+s+"!!!!");};
		Consumer<String> c2=(s)->{System.out.println("HEllo "+s+"!!!!");};
		Consumer<String> c3=s->System.out.println("HEllo "+s+"!!!!");
		
		
		c1.accept("Pradeep");
		c1.accept("Sachin");
		c1.accept("Mohan");
			
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}
