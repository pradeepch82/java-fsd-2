package com.pradeep.corejava.java8;

import java.util.function.Function;
import java.util.function.Predicate;







public class PredicateDemo {

	
	public static void main(String[] args) {
		
		Predicate<Integer> p1=(Integer a)->{return a%2==0;};
		Predicate<Integer> p2=(a)->a%2==0;
		Predicate<Integer> p3=a->a%2==0;
		
		
		System.out.println(p1.test(12));
		System.out.println(p2.test(11));
		System.out.println(p3.test(120));
		
		System.out.println("========================");
		
		Predicate<String> p4=s->s.startsWith("P");
		
		System.out.println(p4.test("AMOL"));
		System.out.println(p4.test("PRATAP"));
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}
