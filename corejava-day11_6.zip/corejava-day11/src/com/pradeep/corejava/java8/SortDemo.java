package com.pradeep.corejava.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortDemo {
	

	
public static void main(String[] args) {
	
	
	
	List<String> list=Arrays.asList("RAM","PRADEEP","SACHIN","MOHAN","PRATAP","SUNIL","MAHESH","AMEYA");
	
	System.out.println("Before Sorting \n=============\n"+list);
	
	Collections.sort(list);	//internally calls compareTo method of Comparable
	Collections.sort(list,(a,b)->b.compareTo(a));//internally calls compareTo method of Comparator
	
	
	System.out.println("After Sorting \n=============\n"+list);
	
	
	
	

	
	
}
}
