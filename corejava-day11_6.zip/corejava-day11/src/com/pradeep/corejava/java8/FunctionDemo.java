package com.pradeep.corejava.java8;

import java.util.function.Function;



@FunctionalInterface
interface A{
	void show1();
	
	default void display() {
		System.out.println("A display");
	}
	
}


public class FunctionDemo {

	
	public static void main(String[] args) {
		
		Function<String, String> f1=(String a)->{ return "Hello  "+a.toUpperCase()+"!!!";};
		Function<String, String> f2=(String a)-> "Hello  "+a.toUpperCase()+"!!!";
		Function<String, String> f3=(a)-> "Hello  "+a.toUpperCase()+"!!!";
		Function<String, String> f4= a-> "Hello  "+a.toUpperCase()+"!!!";
		
		
		
		System.out.println(f1.apply("Pradeep Chinchole"));
		System.out.println(f2.apply("Pradeep Chinchole"));
		System.out.println(f3.apply("Pradeep Chinchole"));
		System.out.println(f4.apply("Pradeep Chinchole"));
		
		
		System.out.println("============================");
		
		Function<Integer, Integer> f5=a->a*a;
		
		System.out.println(f5.apply(11));
		System.out.println(f5.apply(22));
		
		
		
		
		
		
	}
	
	
}
