package com.pradeep.corejava.java8;

import java.util.Arrays;
import java.util.List;

public class LambdaExpressionDemo {
	

void show(String s)
{
System.out.println(s);	
}
	
	
	
	
public static void main(String[] args) {
	
	
	LambdaExpressionDemo led=new LambdaExpressionDemo();
	
	
	System.out.println();
	
	List<String> list=Arrays.asList("RAM","PRADEEP","SACHIN","MOHAN","PRATAP","SUNIL","MAHESH","AMEYA");
	
	System.out.println("Contents \n"+list);
	
	list.stream()
	    .filter(s->s.startsWith("P"))
	    .map(u->"Hello  "+u)
	    .forEach(System.out::println); 
	
System.out.println("======================");	
	list.stream()
    .filter(s->!s.startsWith("P"))
    .map(u->"Hello  "+u)
    .forEach(led::show); 

	
	
}
}
