package com.pradeep.corejava.collections;

import java.util.ArrayList;
import java.util.Scanner;

public class CommonWord {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter sentence 1:");
		String sentence1=sc.nextLine();
		
		System.out.println("Enter sentence 1:");
		String sentence2=sc.nextLine();
		
		
		
		ArrayList<String> arl1=new ArrayList<>();
		ArrayList<String> arl2=new ArrayList<>();
		
			
		//, .?!'
		
		Scanner s1=new Scanner(sentence1);
		s1.useDelimiter("\\W"); 
		
		Scanner s2=new Scanner(sentence2);
		s2.useDelimiter("\\W"); 
		
		
		/*
		 * \\W word char
		 * \\w non-word char
		 * \\D digit
		 * \\d non digit
		 * \\S Whitespace
		 * \\s non whitespace
		 * 
		 * 
		 * 
		 * 
		 * */
		while(s1.hasNext())
			arl1.add(s1.next());
		while(s2.hasNext())
			arl2.add(s2.next());
		
			
		System.out.println("Sentence 1 words "+arl1);
		System.out.println("Sentence 2 words "+arl2);
		
		arl1.retainAll(arl2);
		
		System.out.println("Common words :"+arl1);
			
		
		
		
		
		
		
	}

}
