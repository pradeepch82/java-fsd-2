package com.pradeep.corejava.collections;

import java.util.Arrays;
import java.util.Scanner;

enum Colors{
RED,GREEN,BLUE,MAGENTA,ORANGE;
}







public class EnumDemo {
			
public static void main(String[] args) {
	
	for(Colors c:Colors.values())
	System.out.println("Constant :"+c+"   Name :"+c.name().toLowerCase()+"  Ordinal:"+c.ordinal());

	Scanner sc=new Scanner(System.in);
	
	
	System.out.println("Enter color :");
	String c=sc.next();
	
	
	try {
	Colors colors=Colors.valueOf(c.toUpperCase());
	
	
	switch(colors) {
	
	case RED: System.out.println("RED value");
    break ;
	case GREEN: System.out.println("GREEN value");
    break;
	case BLUE: System.out.println("BLUE value");
    break;
	case MAGENTA: System.out.println("MAGENTA value");
    break;
	case ORANGE: System.out.println("ORANGE value");
    break;
    default :System.out.println("Wrong color...");    
	        
	}
	}
	catch(Exception e) {
		System.out.println("Valid values are :"+Arrays.toString(Colors.values()));
	}
	
	
}
}
