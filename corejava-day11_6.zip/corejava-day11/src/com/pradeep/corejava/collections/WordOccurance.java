package com.pradeep.corejava.collections;

import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;

public class WordOccurance {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter sentence :");
		
		String sentence=sc.nextLine();
		System.out.println("Senetence :"+sentence);
		
		
		
		StringTokenizer st=new StringTokenizer(sentence, " ,.?!'");
			
		
		HashMap<String, Integer> hm=new HashMap<>();
		
		
		
		System.out.println("Tokens are :");
		while(st.hasMoreTokens())
			{
			String s=st.nextToken();
			if(hm.containsKey(s))
			{
			 hm.put(s, hm.get(s)+1); 	
			}
			else
			hm.put(s, 1);	
			  
			}
		
		System.out.println(hm);
	
		System.out.println("===============");
for(String k:hm.keySet())
System.out.println(k+" = "+hm.get(k));	
		
	
	
	}

}
