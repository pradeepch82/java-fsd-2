package com.pradeep.corejava.collections;



class Book  implements AutoCloseable{
	
int id=101;
String name="Java";


@Override
public String toString() {
	return "Book [id=" + id + ", name=" + name + "]";
}


@Override
	public void close() throws Exception {
	id=0;
	name=null;
	System.out.println("Book resource relased...");
	}


}



public class TryWithResourcesDemo {


public static void main(String[] args) {


	
	
	
	try(Book e1=new Book();Book e2=new Book();) {
		
		
		System.out.println("B1  :"+e1);
		System.out.println("B2  :"+e2);
			
		
	}
	catch(Exception e){
		
		e.printStackTrace();
	}
	
	
	
}	
	
	
}
