package com.pradeep.corejava.exceptions;

public class Ex {
	
	public Ex(int a) {
	System.out.println("Ex default constructor...");
	}
	
public static void main(String[] args) {
	
	
	int n=args.length;
	System.out.println("Number of Argument "+n);
	System.out.println("Open files....");
	int a=100/n;
	System.out.println("a ="+a);
	System.out.println("Close the files...");
		
}
}
