package com.pradeep.bank.presentation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pradeep.bank.model.Customer;
import com.pradeep.bank.service.CustomerService;

public class CustomerMainApp {

	private CustomerService cs; // dependency

	public CustomerMainApp() {
		System.out.println("====CustomerMainApp  created==========");
	}

	public CustomerMainApp(CustomerService cs) // constructor injection
	{
		this.cs = cs;
		System.out.println("====CustomerMainApp  param constructor==========");
	}

	public void setCs(CustomerService cs)// setter injection
	{
		this.cs = cs;
		System.out.println("====CustomerMainApp  setCs method...==========");

	}

	public void addCustomer(Customer customer) {

		if (cs.saveCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] added successfully");
		else
			System.out.println("Problem in insertion");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] updated successfully");
		else
			System.out.println("Customer doesn't exist");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with Id [" + customerId + "] deleted successfully");
		else
			System.out.println("Customer doesn't exist");

	}

	public void showCustomer(int customerId) {

		Customer c = cs.findCustomer(customerId);

		if (c != null)
			System.out.println("Customer with Id [" + customerId + "] Details\n====================" + c);

		else
			System.out.println("Customer doesn't exist");

	}

	public void showAllCustomers() {

		System.out.println("============================================================");
		System.out.println("              Customer Details                              ");
		System.out.println("============================================================");
		for (Customer c : cs.findAllCustomers())
			System.out.println(c);
	}

	
	public void init() {
		System.out.println("Customer Main App Initialized.....");
	}
	
	public void destroy() {
		System.out.println("Customer Main App destroyed.....");
	}
	
	
	
	public static void main(String[] args) {

		// create a Spring Container
         
		//XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));
         
	    ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans-autowire.xml");
	        
        System.out.println("Spring container created....");
        

        //get bean from  container
        
          //get bean by type if only one bean of specific type
         //CustomerMainApp cma=c.getBean(CustomerMainApp.class);
         
        //get bean by id when multiple beans of same type
        CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
        cma.showAllCustomers();
                          
           
          //shutdown the container
           c.registerShutdownHook();
               
         
		
	}

}
