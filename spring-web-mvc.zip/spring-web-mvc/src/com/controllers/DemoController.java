package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DemoController {
public DemoController() {
System.out.println("demo Controller created...");
}
@RequestMapping("/hello")
public String hello() {
    return "hello";
}
@RequestMapping("/welcome")
public String welcome() {
    return "welcome";
}
@RequestMapping("/greet")
public String greet() {
    return "greet";
}
@RequestMapping("/today")
public @ResponseBody String today() {
	
    return "Today is " + new java.util.Date();
}
}
