package com.pradeep;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class EncryptDemo {

	public static void main(String[] args) {
		
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		
		System.out.println("pradeep  :"+encoder.encode("RAM"));
		System.out.println("ram  :"+encoder.encode("RAHIM"));
		System.out.println("raj  :"+encoder.encode("DAVID"));
		
		
		
		
		
	}
	
}
