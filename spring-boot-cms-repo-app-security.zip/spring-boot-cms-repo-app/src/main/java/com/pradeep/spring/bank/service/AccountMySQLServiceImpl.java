package com.pradeep.spring.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.spring.bank.dao.AccountRepository;
import com.pradeep.spring.bank.model.Account;

@Service
public class AccountMySQLServiceImpl implements AccountService {

	@Autowired
	private AccountRepository repository;

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return repository.save(account) == account;
	}

	@Override
	public boolean deleteAccount(int accno) {

		Account account = repository.findById(accno).get();

		if (account != null) {
			repository.delete(account);
			return true;
		}

		return false;
	}

	@Override
	public List<Account> findAllAccounts() {
		return repository.findAll();
	}

	@Override
	public Account findAccount(int accno) {

		return repository.findById(accno).get();
	}

	@Override
	public boolean saveAccount(Account account) {

		
		

		Account a = repository.findById(account.getAccno()).get();

		if (a != null) {
			repository.save(account);
			return true;
		}

		return false;
	}

}
