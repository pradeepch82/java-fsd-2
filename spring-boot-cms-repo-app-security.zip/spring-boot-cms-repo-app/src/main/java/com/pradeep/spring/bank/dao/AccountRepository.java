package com.pradeep.spring.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pradeep.spring.bank.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer>{
}
