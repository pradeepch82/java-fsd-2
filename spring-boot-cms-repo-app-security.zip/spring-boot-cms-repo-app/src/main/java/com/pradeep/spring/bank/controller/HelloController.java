package com.pradeep.spring.bank.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@GetMapping("/hello")
	public String hello() {
		return "Hello All";
	}

	@GetMapping("/welcome")
	public String welcome() {
		return "welcome all";
	}
	
	
   @GetMapping("/greet")
	public String greet() {
		return "greet all";
	}
	
}
