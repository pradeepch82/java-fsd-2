package com.pradeep.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class CmsSecurityConfig extends WebSecurityConfigurerAdapter{

	
	
	@Autowired
	private DataSource dataSource;
	
	
	public CmsSecurityConfig() {
	System.out.println("============CmsSecurity Configure adaptoer created ==============");
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		System.out.println("============CmsSecurity  configure  HttpSecurity method==============");
			
		//super.configure(http);
	
	    http.authorizeRequests()
	    .antMatchers("/welcome").hasAnyRole("ADMIN","TEACHER","STUDENT")
	    .antMatchers("/hello").hasAnyRole("ADMIN","TEACHER")
	    .antMatchers("/greet").hasRole("ADMIN")
	    .anyRequest()    
	    .authenticated()
	     .and()
	      //.httpBasic();
	      .formLogin();     
	       	
	}
	
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	
		System.out.println("============CmsSecurity Configure AuthenticationManagerBuilder ==============");
		
		
		auth.jdbcAuthentication()
		    .passwordEncoder(new BCryptPasswordEncoder())
		    .dataSource(dataSource);
		

		/*
		 * auth.inMemoryAuthentication()
		 * .withUser("RAM").password("{noop}RAM").roles("ADMIN").and()
		 * .withUser("RAHIM").password("{noop}RAHIM").roles("TEACHER").and()
		 * .withUser("DAVID").password("{noop}DAVID").roles("STUDENT");
		 */ 		
		
	}
	
	
}
