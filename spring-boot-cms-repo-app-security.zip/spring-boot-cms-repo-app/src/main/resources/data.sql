insert into users(username, password, enabled)values('RAM','$2a$10$mGFh/qIOV8gjY2CVKZx2EOP.OI5cL9RuTho96ZBuXhv7kqrzrLuu2',true);
insert into authorities(username,authority)values('RAM','ROLE_ADMIN');
 
insert into users(username, password, enabled)values('RAHIM','$2a$10$./KQHHs2CUDPPFvziB6aHOFoSaKsOe3ilHgAwT/zT5J.wC.yPO5Me',true);
insert into authorities(username,authority)values('RAHIM','ROLE_TEACHER');


insert into users(username, password, enabled)values('DAVID','$2a$10$v8nD.ki3sLDb3LQAmVuNDeh8/29JnbKZWs9UTlKKF05iuf06nHMLK',true);
insert into authorities(username,authority)values('DAVID','ROLE_STUDENT');

