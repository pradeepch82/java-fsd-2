import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit,OnDestroy{

  constructor() { 
    console.log("============TechnologiesComponent component created===============");
  }

  ngOnInit(): void {
    console.log("============TechnologiesComponent component initialized===============");
    
  }

  ngOnDestroy(): void {
    console.log("============TechnologiesComponent component destroyed===============");
  }

}
