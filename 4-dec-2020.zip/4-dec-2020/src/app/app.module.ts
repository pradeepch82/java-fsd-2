import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { NestedComponent } from './nested/nested.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

@NgModule({
  declarations: [ //components,directives,pipes
    AppComponent, 
    HomeComponent, 
    AngularBasicsComponent,
    TechnologiesComponent,
    AngularPipesComponent,
    NestedComponent,
    ViewChildComponent,
    CustomDirectivesComponent,
    SpringBootComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],//services
  //bootstrap: [AppComponent,HomeComponent,AngularBasicsComponent,]//component
  bootstrap: [AppComponent]
})
export class AppModule { }




