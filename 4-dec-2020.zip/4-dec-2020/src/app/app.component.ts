import { Component } from '@angular/core';

@Component({
  selector: 'app-root',//where to inject
  templateUrl: './app.component.html',//where to display
  template: '<i>Hello   :{{title}}</i>',//where to display
  
  styleUrls: ['./app.component.css'] //how to display
})
export class AppComponent {
  title = 'Pradeep App';//what to display
}
