package com.madhu.basics.corejava;

abstract class Instrument{
	abstract void play();
	}

class Piano extends Instrument {
	void play() {
System.out.println("Piano is playing : Dan dan dan!");		
	}
}
class Guitar extends Instrument {
	void play() {
System.out.println("Guitar is playing : ting ting ting!");		
	}
}
class Flute extends Instrument {
	void play() {
System.out.println("flute is playing : too too too!");		
	}
}

public class InstrumentDemo {

	public static void main(String[] args) {
		
Instrument i = null;
Piano p = new Piano();
Guitar g = new Guitar();
Flute f = new Flute();

i = p;
i.play();
i = g;
i.play();
i = f;
i.play();
	}

}
