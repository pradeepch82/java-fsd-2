package com.pradeep.cms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pradeep.cms.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{

	
	
	@Query(value = "FROM Customer c WHERE c.city=:city")
	List<Customer> findAllByCity(@Param("city") String city);
	
	@Query(value = "FROM Customer c WHERE c.address=:address")
	List<Customer> findAllByAddress(@Param("address") String city);
	
	@Query(value = "FROM Customer c WHERE c.state=:state")
	List<Customer> findAllByState(@Param("state") String city);
	
	
	
	
}
