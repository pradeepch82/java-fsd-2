package com.pradeep.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAopTxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAopTxApplication.class, args);
	}

}
