package com.anusha.corejava.basics;

public class Storage {
	
	private int n;
	boolean flag;

	synchronized public int getN() {
		if(!flag)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println("Get N : "+n);
		flag = false;
		notify();
		return n;
	}

	synchronized public void setN(int n) {
			if (flag)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Set N : "+n);
			this.n = n;
			flag= true;
			notify();
	}
}
