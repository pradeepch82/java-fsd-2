package com.anusha.corejava.basics;

public class InterThreadCommunication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Storage s= new Storage();
		Printer p = new Printer(s);
		Counter c = new Counter(s);
	}

}
