package com.anusha.corejava.basics;

public class Counter extends Thread {

	Storage s =  null;

	public Counter(Storage s) {
		super();
		this.s = s;
		start();
	}
	
	@Override
	public void run() {
		int n=0;
		while(true)
		{
			s.setN(n++);
		}
	}
	
}
