package com.anusha.corejava.basics;

public class Printer extends Thread {

	Storage s =  null;

	public Printer(Storage s) {
		super();
		this.s = s;
		start();
	}
	
	@Override
	public void run() {
		while(true)
		{
			s.getN();
		}
	}
	
}
