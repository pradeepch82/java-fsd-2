package com.pradeep.spring.bank.presentation;

import com.pradeep.spring.bank.dao.MapAccountDaoImpl;
import com.pradeep.spring.bank.model.Account;
import com.pradeep.spring.bank.service.AccountService;
import com.pradeep.spring.bank.service.AccountServiceImpl;

public class MainApp {

	private AccountService as;

	public MainApp() {

		System.out.println("=========MainApp created============");
	}

	public AccountService getAs() {
		return as;
	}

	public void setAs(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp setAs method....============");

	}

	public MainApp(AccountService as) {
		this.as = as;

		System.out.println("=========MainApp param constructor....============");

	}

	public void addAccount(Account account) {

		if (as.addAccount(account))
			System.out.println("Account added successfully");
		else
			System.out.println("Problem in adding the account");

	}

	public void saveAccount(Account account) {

		if (as.saveAccount(account))
			System.out.println("Account update successfully");
		else
			System.out.println("Account doesnot exist");

	}

	public void deleteAccount(int accno) {

		if (as.deleteAccount(accno))
			System.out.println("Account deleted successfully");
		else
			System.out.println("Account doesnot exist");

	}

	public void findAccount(int accno) {

		Account a = as.findAccount(accno);

		if (a != null)
			System.out.println("Account Details \n\n================" + a);
		else
			System.out.println("Account doesnot exist");

	}

	public void findAllAccounts() {
			System.out.println("Account Details \n\n================");
			
			for(Account a:as.findAllAccounts())
               System.out.println(a);  
	}
	
	
	
	public static void main(String[] args) {

		MapAccountDaoImpl madi=new MapAccountDaoImpl();
		
		AccountServiceImpl asi=new AccountServiceImpl();
		
		
		asi.setAccountDao(madi);
				
		MainApp ma=new MainApp();
		ma.setAs(asi);
		
		
		ma.findAllAccounts();
		
		
		
		
		
	}

}
