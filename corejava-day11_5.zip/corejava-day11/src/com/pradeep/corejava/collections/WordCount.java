package com.pradeep.corejava.collections;

import java.util.Scanner;

public class WordCount {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter sentence :");
		
		String sentence=sc.nextLine();
		System.out.println("Senetence :"+sentence);
		//, .?!'
		
		Scanner s=new Scanner(sentence);
		s.useDelimiter("\\W"); 
		/*
		 * \\W word char
		 * \\w non-word char
		 * \\D digit
		 * \\d non digit
		 * \\S Whitespace
		 * \\s non whitespace
		 * 
		 * 
		 * 
		 * 
		 * */
		int n=0;
		System.out.println("Tokens are :");
		while(s.hasNext())
			{System.out.println(s.next());
			  n++;
			}
		
		System.out.println("Number of words :"+n);
		
	}

}
