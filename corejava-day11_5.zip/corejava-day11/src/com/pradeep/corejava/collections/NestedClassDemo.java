package com.pradeep.corejava.collections;



class Outer{
	
	
void show() {
	
	new Inner2().show();
	
}	
	

//Nested Inner class	
class Inner{
	
void show() {
	System.out.println("Inner class show method");
}
	
}	

//Nested Inner class	
private class Inner2 {
	
void show() {
	System.out.println("Inner2 class show method");
}
	
}	


//Nested Inner class	
static class Inner1{
	
void show() {
	System.out.println("Static Inner1 class show method");
}
	
}	

	
void display() {
	
	
	class A{
		void show() {
			System.out.println("Method Inner class show");
		}
		
	}
	
	class B{
		void show() {
			System.out.println("Method Inner class show");
		}
		
	}
	
	class C{
		void show() {
			System.out.println("Method Inner class show");
		}
		
	}
	
	A a=new A();
	a.show();
}



	
}





public class NestedClassDemo {
public static void main(String[] args) {
	
	Outer o=new Outer();
	
	//Normal Nseted class
	Outer.Inner oi=o.new Inner();
	
	oi.show();
	o.show();//private Inner2 class shwo
	
	//static inner class
	
	Outer.Inner1 oi2=new Outer.Inner1();
	
	oi2.show();
	
	o.display();
	
	
	
}
}
