package com.pradeep.corejava.collections;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

Map<String, Double> map;
	
public MapDemo() {
	//map=new HashMap<>();
	map=new LinkedHashMap<>();
	//map=new Hashtable<>();
	//map=new TreeMap<>();

}
	
void add() {
	
	map.put("RAM", 45.66);
	map.put("RAHIM", 25.66);
	map.put("DAVID", 85.66);
	map.put("MOHAN", 65.66);
	map.put("RAM", 77.66);
	
	System.out.println("Contents :");
	System.out.println(map);
		
	System.out.println("Size :"+map.size());
	System.out.println("KeySet :"+map.keySet());
	System.out.println("Values :"+map.values());
	System.out.println(map.containsKey("RAM"));
	
	
	
}




	
	
public static void main(String[] args) {

	MapDemo md=new MapDemo();
	
	md.add();
	
	
	
	
	
	
	
	
}
}
