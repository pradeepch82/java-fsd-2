package com.pradeep.corejava.collections;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;



//my custom annotation



@Documented //marker annotation
@Inherited //marker annotation
@Retention(RetentionPolicy.RUNTIME)  //single valued annotation
@Target({ElementType.TYPE,ElementType.METHOD})//single valued annotation
@interface Course{
    /** hold the id of course */
	public int id() default 101;

	/** hold the name of course */
	
	public String name() default "Java" ;
	/** hold the price of course */
	
	public int price() default 1000;
	
}









@Course(id = 234,name = "PCF",price = 23444)
class Employee{
	

/** stores the id of employee */
private int id=101;


/** stores the name of employee */
private String name="Pradeep";

@SuppressWarnings({ "unused", "rawtypes" }) //single valued annotation
@Override  //marker annotation
public String toString() {
	ArrayList arl=new ArrayList();
	
	
	int a=100;
	int b=200;
	
	
	return "Student [id=" + id + ", name=" + name + "]";
}
	
}



//This is my first program

public class AnnotationsDemo {

public static void main(String[] args) {
	
	
	Employee e=new Employee();
	
	Course c=e.getClass().getAnnotation(Course.class);
	
	System.out.println("Emp Details "+e);
	System.out.println("Course  Id  "+c.id());
	System.out.println("Corse Name  "+c.name());
	System.out.println("Course Price"+c.price());
	
	
	
	
}
}
