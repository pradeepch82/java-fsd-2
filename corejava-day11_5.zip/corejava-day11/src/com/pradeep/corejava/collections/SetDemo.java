package com.pradeep.corejava.collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	
	
Set<String> set;

public SetDemo() {

	//set=new HashSet<>();  //not ordered
	//set=new LinkedHashSet<>(); //insertion order
	set=new TreeSet<>();

}
	
void add() {
	
	System.out.println(set.add("RAM"));
	System.out.println(set.add("RAHIM"));
	System.out.println(set.add("DAVID"));
	System.out.println(set.add("PRADEEP"));
	System.out.println(set.add("SACHIN"));
	System.out.println(set.add("RAM"));
	System.out.println(set.add("PRAMOD"));
	
	
	System.out.println("Contents :");
	System.out.println(set);
	
}

	
	
	
public static void main(String[] args) {
	
	SetDemo sd=new SetDemo();
	
	sd.add();
	
}
}
