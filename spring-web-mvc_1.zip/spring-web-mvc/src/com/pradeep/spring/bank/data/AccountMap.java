package com.pradeep.spring.bank.data;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.spring.bank.model.Account;

public enum AccountMap {

	INSTANCE;

	private Map<Integer, Account> map;

	private AccountMap() {
		map = new HashMap<>();
		Account a1 = new Account("Pradeep Chinchole", 20000.9999);
		Account a2 = new Account("Sachin Chinchole", 60000.9999);
		Account a3 = new Account("Mohan Chinchole", 40000.9999);
		Account a4 = new Account("Mahesh Chinchole", 30000.9999);

		map.put(a1.getAccno(), a1);
		map.put(a2.getAccno(), a2);
		map.put(a3.getAccno(), a3);
		map.put(a4.getAccno(), a4);

	}
	
	
	
	public Map<Integer, Account> getMap() {
		return map;
	}
	
	

}
