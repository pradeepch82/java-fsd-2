package com.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class HelloController {
public HelloController() {
System.out.println("Hello Controller created...");
}
}
